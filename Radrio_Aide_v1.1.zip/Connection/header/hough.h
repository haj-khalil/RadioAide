#ifndef HOUGH_H_
#define HOUGH_H_

#include "include.h"

namespace diff {

class Hough {
public:
    Hough();
    virtual ~Hough();

public:
    int FctHough(unsigned char* img_data, int w, int h);
    std::vector<std::pair<std::pair<int, int>, std::pair<int, int>>> GetLines(int threshold);
    const unsigned int* GetAccu(int* w, int* h);

private:
    unsigned int* _accu;
    int _accu_w;
    int _accu_h;
    int _img_w;
    int _img_h;
    static constexpr double HOUGH_H_SCALE = 2.0;
    static constexpr int MAX_NEIGHBORHOOD = 4;
};

}

#endif /* HOUGH_H_ */
