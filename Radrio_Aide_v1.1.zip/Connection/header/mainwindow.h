#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "descripteur_view.h"
#include "uploadimage.h"
#include "include.h"
#include "login.h"
#include "user.h"


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btn_connection_clicked();

private:
    Ui::MainWindow *ui;
    Descripteur_view *descripteur_view; // Fenêtre pour l'affichage des données
};
#endif // MAINWINDOW_H
