#ifndef DATA_H
#define DATA_H

#include "include.h"
#include "image.h"
#include "descripteur.h"
#include "login.h"

class Data
{
private:
    std::vector<Image> _img_list; // Liste des images
    std::vector<descripteur> _desc_list; // Liste des descripteurs

public:
    // Constructor
    Data();
    Data(string &img_path, string &desc_path);

    // Getters
    int getDescSize();
    string get(int &elem_idx, int &desc_idx);

    Image getImg(int &img_idx);
    descripteur& getDesc(int &desc_idx);

    // Methods
    std::vector<std::string> file_list(string &dir_path);
    void triID(bool inv);
    void triCout(bool inv);

    void addElem(Image &img, descripteur &desc);
    void deleteElem(int pos);

    void exportData(string &path);

    void cleanDir(string &path);

    void cleanData();

    void tri_conditionnel(float inf, float sup);
};

#endif // DATA_H
