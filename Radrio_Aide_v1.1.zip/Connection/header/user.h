#ifndef USER_H
#define USER_H

#include "include.h"

class User
{
private:
    int _role; // Rôle équivalent aux droits d'utilisation
    string _username;  // Nom

public:
    // Constructors
    User();
    User(int role, string username);

    // Setter
    void setRole(int role);
    void setUsername(string username);

    // Getter
    int getRole();
    string getUsername();
};

#endif // USER_H
