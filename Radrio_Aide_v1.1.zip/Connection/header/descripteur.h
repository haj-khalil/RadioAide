#ifndef DESCRIPTEUR_H
#define DESCRIPTEUR_H

#include "include.h"

class descripteur
{
private:
    int _id_descripteur;
    string _titre;
    string _patient;
    string _technique;
    string _acces; // Restreint ou Libre d'accés
    float _cout;
    long _poids;
    string _source;
    string _taille;

    std::vector<string> _lines; // Liste des lignes du fichier descripteur
    string _path; // Chemin vers le descripteur

public:
    // Constructors
    descripteur();
    descripteur(std::vector<std::string> lines, string path);
    descripteur(
        int _id_descripteur,
        string _titre,
        string _patient,
        string _technique,
        string _acces,
        float _cout,
        long long int _poids,
        string _source,
        string _taille);

    // Getters
    int getID();
    std::vector<string> getLines();
    string getPath();
    float getCout();

    // Setters
    void setID(int &id);
    void setPath(string &path);
    void setPoids(size_t &poids);
    void setTaille(string &taille);

    // Methods
    void affiche();
    void writeToFile(const string &path) const;

};

#endif // DESCRIPTEUR_H
