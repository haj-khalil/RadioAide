#ifndef IMAGEEDITOR_H
#define IMAGEEDITOR_H

#include "include.h"
#include "image.h"
#include "hough.h"

namespace Ui {
class ImageEditor;
}

class ImageEditor : public QDialog
{
    Q_OBJECT

public:
    explicit ImageEditor(Image img, QWidget *parent = nullptr);
    ~ImageEditor();

private slots:
    void on_apply_moy_filter_clicked();

    void on_quit_btn_clicked();

    void on_gauss_size_slider_valueChanged(int value);

    void on_gauss_intensity_slider_valueChanged(int value);

    void on_apply_gauss_filter_clicked();

    void on_moy_size_slider_valueChanged(int value);
    void on_segColor_btn_clicked();

    void on_H_slider_valueChanged(int value);
    void on_S_slider_valueChanged(int value);
    void on_V_slider_valueChanged(int value);
    void on_H_slider_2_valueChanged(int value);
    void on_S_slider_2_valueChanged(int value);
    void on_V_slider_2_valueChanged(int value);

    void display_color();
    void display_color2();
    void display_color3();
    void display_color4();

    void on_Hough_transform_canny_btn_clicked();
    void on_Hough_transform_btn_clicked();

    void doFctHoughCanny(std::string file_path, int threshold, vector<int> RGB);
    void doFctHough(std::string file_path, int threshold, int size, float intensity, int seuil_bas, int seuil_haut, vector<int> RGB, int method);

    void on_ChartPLot_clicked();

    void on_canal_selection_currentIndexChanged(const QString &arg1);

    void on_greyscale_btn_toggled(bool checked);

    void on_exp_intensity_slider_valueChanged(int value);

    void on_apply_exp_filter_clicked();

    void on_Laplacien_btn_clicked();

    void on_Sobel_hor_clicked();

    void on_Sobel_vert_clicked();

    void on_Sobel_btn_clicked();

    void on_contour_factor_slider_valueChanged(int value);

    void on_threshold_slider_valueChanged(int value);

    void on_contour_enhance_btn_clicked();

    void on_save_btn_clicked();

    void on_Rouge_slider_valueChanged(int value);

    void on_Vert_slider_valueChanged(int value);

    void on_Bleu_slider_valueChanged(int value);

    void on_hough_gauss_size_slider_valueChanged(int value);

    void on_hough_gauss_intensity_slider_valueChanged(int value);

    void on_Rouge_seg_slider_valueChanged(int value);

    void on_Vert_seg_slider_valueChanged(int value);

    void on_Bleu_seg_slider_valueChanged(int value);

private:
    Ui::ImageEditor *ui;
    Image _img; // Image à modifier
    Image _img_bckp; // Copie de l'imge initiale
};

#endif // IMAGEEDITOR_H
