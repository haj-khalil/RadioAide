#ifndef LOGIN_H
#define LOGIN_H

#include "include.h"

class Login
{
   const static  int  droit =0;
public:

    Login();
    static std::vector<std::string> file_list();

    static std::vector<std::string> file_to_lines(string file_path , int num);

    bool login_test(string username, string password);

    // Récupérer le role de l'utilisateur
    int getUserRole(string username);
};

#endif // LOGIN_H
