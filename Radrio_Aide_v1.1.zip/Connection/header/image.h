#pragma once
#ifndef IMAGE_H__
#define IMAGE_H__

#include "include.h"

class Image {
private:
    cv::Mat _image; // Image sous forme d'une matrice OpenCV
    vector<int> _taille; // Dimension de l'image : lignes puis colonnes
    bool _multicanal; // Caractère multicanal (true) ou monocanal (false)
    string _path; // Chemin vers l'image
    int _ID; // Identifiant de l'image

public:
    // Constructors
    Image(std::string path, bool multicanal);
    Image();

    // Getters
    cv::Mat getImage();
    std::vector<int> getSize();
    bool getMulticanal();
    string getPath();
    int getID();
    string getSizeStr();

    // Setters
    void setImage(cv::Mat img);
    void setMulticanal(bool multicanal);
    void setID(int ID);
    void setPath(string &path);


    // Methods
    void Afficher();
    void Save(const string& path) const;
    void Taille();
    vector<vector<int>> Histogramme(int bins = 10);
    void Inverser();
    void Binariser(int seuil_bas, int seuil_haut);
    void GreyScale();
    void IsolerCanal(int& id);

    // Fonction pour la convolution
    void Conv(cv::Mat filter);
    cv::Mat generateGaussianFilter(int size, double sigma);
    void applyGaussianBlur(int size, double sigma);
    void applyMoyFilter(int size);

    cv::Mat generateExpFilter(int size, double lambda);
    void applyExpFilter(int size, double lambda);

    // Detection des contours (Filtre Laplacien)
    void DetectContours();

    // Detection des contours (gradients)
    void DetectContoursGradient();

    //rehaussement de contours par laplacien
    void EnhanceContoursLaplacian(double alpha, double seuil);

    // Gradient Sobel X
    void DetectContoursGradientX();

    // Gradient Sobel Y
    void DetectContoursGradientY();

    // Operator=
    Image& operator=(const Image& other);
};


#endif
