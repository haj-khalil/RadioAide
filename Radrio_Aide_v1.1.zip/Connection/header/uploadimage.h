#ifndef UPLOADIMAGE_H
#define UPLOADIMAGE_H

#include "include.h"
#include "image.h"
#include "descripteur.h"
#include "login.h"

namespace Ui {
class UploadImage;
}

class UploadImage : public QDialog
{
    Q_OBJECT

public:
    explicit UploadImage(QWidget *parent = nullptr);
    ~UploadImage();


    void creat_descripteur_file(std::vector<std::string> descripteur_info);

    std::vector<string> getNewINfo();

    int input_test(std::vector<std::string> info);

    void changerNomEtCopierImage(  QString nouveauNom) ;


private slots:

    void on_ptn_save_clicked();

    void on_ptn_parcourir_clicked();


    void on_quit_btn_clicked();

    void on_generate_img_clicked();

private:
    Ui::UploadImage *ui;
};

#endif // UPLOADIMAGE_H
