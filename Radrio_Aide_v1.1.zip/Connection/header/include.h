
#ifndef INCLUDES_H
#define INCLUDES_H

// Bibliothèques standards C++
#include <iostream>       // Flux d'entrée-sortie standard
#include <fstream>        // Flux de fichier
#include <algorithm>      // Algorithmes c++ (tri, trouver un élément dans une chaîne de caractère)
#include <vector>         // Implémentation de vecteurs dynamiques en c++
#include <string>         // Classe de chaîne de caractères
#include <cctype>         // Fonctions de manipulation de caractères
#include <cstdio>         // Entrée-sortie standard C
#include <typeinfo>       // Information de type
#include <cmath>          // Fonctions mathématiques standard

// Bibliothèque Eigen pour les opérations mathématiques et matrices
#include <Eigen/Dense>            // Bibliothèque Eigen pour les matrices et vecteurs

// Bibliothèques Qt pour interfaces graphiques et utilitaires
#include <QDebug>         // Affichage de messages de débogage
#include <QMessageBox>    // Gestion des boîtes de message
#include <QColorDialog>   // Boîte de dialogue pour les choix de couleur
#include <QColor>         // Gestion des couleurs
#include <QPalette>       // Palette pour la gestion des couleurs des widgets
#include <QDialog>        // Classe de base pour les fenêtres de dialogue
#include <QWidget>        // Classe de base pour tous les widgets
#include <QFileDialog>    // Boîte de dialogue pour ouvrir/sauvegarder des fichiers
#include <QMainWindow>    // Classe de base pour les fenêtres principales
#include <QFile>          // Manipulation de fichiers
#include <QPixmap>        // Insertion d'images sur l'interface graphique Qt
#include <QBuffer>        // Buffer pour la lecture/écriture de données en mémoire
#include <QByteArray>     // Tableau d'octets
#include <QPainter> 	  // Utilisé pour afficher des images sur des widgets Qt


// Bibliothèques pour la création de graphiques avec Qt
#include <QtCharts>               // Bibliothèque pour les graphes sous Qt
#include <QtCharts/QChartView>    // Vue pour l'affichage de graphiques
#include <QtCharts/QLineSeries>

// Bibliothèques OpenCV pour le traitement d'images
#include <opencv2/opencv.hpp>     // Bibliothèque principale OpenCV
#include "opencv2/highgui.hpp"    // Fonctions d'interface graphique High-level

// Bibliothèques pour la gestion des systèmes de fichiers
#include <dirent.h>               // Lecture de répertoires (UNIX)
#include <filesystem>             // Manipulation de fichiers (C++17)
#include <boost/filesystem.hpp>   // Bibliothèque Boost la manipulation de fichiers (C++11)

using namespace cv;
using namespace std;

// Ajoutez d'autres #include au besoin

#endif // INCLUDES_H
