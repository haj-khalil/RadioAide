#ifndef DESCRIPTEUR_VIEW_H
#define DESCRIPTEUR_VIEW_H

#include <QMainWindow>
#include "formmodification.h"
#include "uploadimage.h"
#include "imageeditor.h"
#include "user.h"
#include "include.h"
#include "image.h"
#include "data.h"

namespace Ui {
class Descripteur_view;
}

class Descripteur_view : public QMainWindow
{
    Q_OBJECT

public:
    explicit Descripteur_view(User user, QWidget *parent = nullptr);
    ~Descripteur_view();

    // Lectures des descripteurs contenus dans le répertoire
    void loaddata();

    // MAJ des descripteurs
    void updatedesc();

    void copyFolder(const std::string& sourceDir, const std::string& destDir);

    std::vector<float> stat_cout();

private slots:
    void on_pushButton_clicked();

    void on_Descriptor_list_cellDoubleClicked(int row, int column);

    void on_ptn_new_image_clicked();

    void on_Tri_ID_clicked();

    void on_reload_btn_clicked();

    void on_btn_tri_cout_clicked();

    void on_export_btn_clicked();

    void on_load_btn_clicked();

    void on_reset_btn_clicked();

    void on_search_btn_clicked();

    void on_Tri_ID_dec_clicked();

    void on_btn_tri_cout_dec_clicked();

    void on_condition_show_btn_clicked();

    void on_stat_btn_clicked();

private:
    Ui::Descripteur_view *ui;
    FormModification *formModification; // fenêtre de modification d'une donnée de la bibliothhèque
    ImageEditor *imageeditor; // fenêtre de moficiation d'une image
    UploadImage *uploadimage; // fenêtre d'ajout d'image
    User _user; // Utilisateur qui se connecte à l'application
    Data _data; // Données, équivalent à la bibliothèque d'images et descripteurs
};

#endif // DESCRIPTEUR_VIEW_H
