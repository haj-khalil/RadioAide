#ifndef FORMMODIFICATION_H
#define FORMMODIFICATION_H

#include "include.h"
#include "image.h"
#include "descripteur.h"
#include "login.h"

namespace Ui {
class FormModification;
}

class FormModification : public QWidget
{
    Q_OBJECT

public:
    explicit FormModification(descripteur &desc, Image &img, QWidget *parent = nullptr);
    ~FormModification();

    std::vector<QString> InfoModification(std::vector<QString> info);
    std::vector <QString> getModifiedDescription();
    void update_line(string file_path, int nb_line, string new_line);
    void update_descripteur_file(std::vector<std::string> descripteur_info ,std::string full_path);
    void on_ptn_parcourir_clicked();

private slots:
    void on_ptn_save_clicked();

    void on_btn_parcourir_clicked();

    void on_quit_btn_clicked();

private:
    Ui::FormModification *ui;
    descripteur _desc;
    Image _img;
};

#endif // FORMMODIFICATION_H
