#include "login.h"

// Constructor
Login::Login()
{

}

//! Fonction pour récupếrer les fichiers des descripteurs dans le dossier de l'application : /Connection/descripteur/
std::vector<std::string> Login::file_list()
{
    std::vector<std::string> file_list;
    string dir_path = "../Connection/descripteur";
    DIR *dir = opendir(dir_path.c_str());

    if (dir == NULL)
    {
        cout << "Impossible d'accéder au dossier";
    }

    struct dirent *object;
    object = readdir(dir);

    while (object != NULL)
    {
        if (object->d_type == DT_REG)
        {
            std::string basePath = "../Connection/descripteur/";
            std::string fullPath = basePath + object->d_name;
            file_list.push_back(fullPath);
        }
        object = readdir(dir);
    }

    closedir(dir);
    return file_list;
}

//!! Convertir un fichier en vecteur de lignes, paramètre supplémentaire pour ne pas lire les num derniers éléments d'une lignes
std::vector<std::string> Login::file_to_lines(string file_path , int num)
{
    fstream myFile;
    myFile.open(file_path, ios::in); // mode read
    vector<string> lines;
    if (myFile.is_open())
    {
        string line;
        while (getline(myFile, line))
        {
            // Supprimer le caractère "\n" - Linux seulement
            line = line.substr(0, line.size()-num);

            lines.push_back(line);
        }
        myFile.close();
    }
    else
        cout << "Impossible d'ouvrir le fichier";

    return lines;
}

//! Fonction pour effectuer le test  afin de savoir si la combinaison ( utilisateur , mot de passe ) est bonne et  si la connexion est donc possible
bool Login::login_test(string username, string password){
    bool success = 0;

    std::vector<std::string> usernames = file_to_lines("../Connection/login/username.txt",1);
    std::vector<std::string> passwords = file_to_lines("../Connection/login/password.txt",1);
    std::vector<std::string> roles = file_to_lines("../Connection/login/role.txt",1);

    for (int i = 0 ; i< usernames.size() ; i++){
        if(username == usernames[i]){
            if(password == passwords[i]){
                cout << "Authentification réussie !"<<endl;
                success = 1;
                if( roles[i]=="1"){
                cout << "Vous êtes un administrateur" <<endl;
                }else
                break;
            }else cout << "Mot de passe ou nom d'utilisateur incorrct !"<<endl;
        }else if(i == usernames.size()-1){
            cout << " L'utiliisateur n'est pas enregistrée dans la base d'accès ! " <<endl;
        }
    }

    return success;
}

//! Récupérer le role de l'utilisateur en fonction de son nom
int Login::getUserRole(string username){
    int role;

    std::vector<std::string> usernames = file_to_lines("../Connection/login/username.txt",1);
    std::vector<std::string> roles = file_to_lines("../Connection/login/role.txt",1);

    for (int i = 0 ; i< usernames.size() ; i++){
        if(username == usernames[i]){

            role = stoi(roles[i]);
         }

    }

    return role;
}


