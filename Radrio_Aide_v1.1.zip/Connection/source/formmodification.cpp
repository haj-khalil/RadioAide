#include "formmodification.h"
#include "ui_formmodification.h"


//! Constructeur de la fenêtre pour la modification d'une donnée sélectionnée dans le tableau de la fenêtre principale
FormModification::FormModification(descripteur &desc, Image &img, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormModification)
{
    ui->setupUi(this);
    _desc = desc;
    _img = img;

    string path = _img.getPath();

    QString path_qt = QString::fromStdString(path);
    QPixmap mod_img_disp(path_qt);
    ui->img_show->setPixmap(mod_img_disp);
    ui->img_show->setScaledContents(true);

    ui->input_path->setText(path_qt);
}

//! Desctructeur
FormModification::~FormModification()
{
    delete ui;
}

//! Modifier Une ligne particulière dans un fichier existant
void FormModification::update_line(string file_path, int nb_line, string new_line)
{
    fstream myFile;
    std::vector<std::string> lines = Login::file_to_lines(file_path,0);

    // verifier si la line existe
    if (nb_line >= lines.size())
    {
        cout << "Numéro de ligne invalide \n Le nombre de lignes dans le fichier est " << lines.size() << endl;

    }

    lines[nb_line] = new_line;
    myFile.open(file_path, ios::out);
    if (myFile.is_open())
    {
        for (int i = 0; i < lines.size(); i++)
        {
            if (i != nb_line)
            {
                myFile << lines[i] << endl;
            }
            else
                myFile << lines[nb_line] << endl;
        }
    }
    else
        cout << "Le fichier n'a pas pu être ouvert";
    myFile.close();
    cout << "Ligne mise à jour" << endl;

    _desc = descripteur(lines,_desc.getPath());
};



//! Mise à jour d'un fichier descripteur existant
void FormModification::update_descripteur_file(std::vector<std::string> descripteur_info ,std::string full_path)
{
    fstream myFile;

    myFile.open(full_path, ios::out);
    if (myFile.is_open())
    {
        for (int i = 0; i < descripteur_info.size(); i++)
        {

                myFile << descripteur_info[i] << endl;

        }
    }
        myFile.close();
        cout << "Le fichier descripteur  " << descripteur_info[0] <<".txt a été mis à jour"  << endl;


};


//! Actualiser l'interface graphique en fonction des informations du descripteur à modifier
std::vector<QString>  FormModification::InfoModification(std::vector<QString> info)
{
    ui->input_id->setText(info[0]);
    ui->input_titre->setText(info[1]);
    ui->input_patient->setText(info[2]);
    ui->input_technique->setText(info[3]);

    // Vérifier si l'image est en mode restreint ou en mode accès libre
    QString restricted = "R";
    if (info[4] == restricted)
        ui->access_choice->setCurrentIndex(1);
    else
        ui->access_choice->setCurrentIndex(0);


    ui->input_cout->setText(info[5]);
    ui->input_poids->setText(info[6]);
    ui->input_source->setText(info[7]);
    ui->input_taille->setText(info[8]);

    return info;
}


//! Récupérer les modifications faites dans les champs de l'interface
std::vector<QString> FormModification::getModifiedDescription()
{
    std::vector<QString> infoModified;

     QString  id = ui->input_id->text();
     QString acces =ui->access_choice->currentText();
     QString patient =ui->input_patient->text();
     QString cout = ui->input_cout->text();

     QString  source =ui->input_source->text();
     QString  technique=ui->input_technique->text();
     QString  poids=ui->input_poids->text();
     QString  titre =ui->input_titre->text();
     QString  taille=ui->input_taille->text();

     infoModified.push_back(id);
     infoModified.push_back(titre);
     infoModified.push_back(patient);
     infoModified.push_back(technique);
     infoModified.push_back(acces);
     infoModified.push_back(cout);
     infoModified.push_back(poids);
     infoModified.push_back(source);
     infoModified.push_back(taille);

return infoModified;
}

//! Sauvegarde des modifications de l'élément de donnée dans les fichiers (decsritpeur et image) à la place du précédent
void FormModification::on_ptn_save_clicked()
{
    std::vector<QString> infoModified = FormModification::getModifiedDescription() ;

    for (int i=0 ; i<infoModified.size();i++){
        qDebug() <<infoModified[i];
        cout <<"fini modified info"<<endl;
    }
    cout<<"entre"<<endl;
    std::string file_name = infoModified[0].toStdString();
    cout<<file_name<<endl;
    std::string path= "../Connection/descripteur/";
    std::string extention = ".txt";
    std::string full_path = path+file_name+extention;

    cout <<full_path<<endl;


        QMessageBox::StandardButton reponse ;
        reponse = QMessageBox::question(this,"Confirmation Message", "Voulez-vous sauvegarder ces changements ? ",QMessageBox::Yes |QMessageBox::No );

        if(reponse==QMessageBox::Yes){


            std::vector<std::string> new_lignes;

            for(int  i =0 ; i<infoModified.size();i++)
            {
                new_lignes.push_back(infoModified[i].toStdString());
            }

            try {
                std::vector<string> lines(infoModified.size(),"");

                for(int i=0; i<infoModified.size(); i++)
                {
                    lines[i] = infoModified[i].toStdString();
                }

                _desc = descripteur(lines, _desc.getPath());
                _desc.affiche();

                FormModification::update_descripteur_file(new_lignes , full_path);
                QMessageBox::information(this, "Information", QString("Ajout réussi, appuyer sur le bouton 'Mettre à jour' pour afficher les changements"));
                hide() ;


            }  catch (const std::exception& e) {
                QMessageBox::warning(this, "Attention", QString("Certaines cases ne contiennent pas le bon type d'informations"));
            }


        }else
        {
            QMessageBox::critical(this,"Message importent ","Les changements n'ont pas été sauvegardés");
            hide() ;
        }


}

//! Renseigner une nouvelle destination pour l'image
void FormModification::on_btn_parcourir_clicked()
{
    std::cout << "Le bouton parcourir à été enfoncé" << endl;
    QString imagePath = QFileDialog::getOpenFileName(this, tr("Choisir une image"), QCoreApplication::applicationDirPath(), tr("Images (*.png *.jpg *.bmp *.jpeg)"));

        if (!imagePath.isEmpty()) {
            // Display the selected image
            QPixmap image(imagePath);
            ui->img_show->setPixmap(image);
            ui->img_show->setScaledContents(true);  // Scale the image to fit the label

            ui->input_path->setText(imagePath);

            string prev_path = _img.getPath();

            // Charger la nouvelle image
            _img = Image(imagePath.toStdString(),true);

            // Sauvegarde de l'image
            _img.Save(prev_path);

            ui->input_taille->setText(QString::fromStdString(_img.getSizeStr()));

            cv::Mat img = _img.getImage();
            size_t imageSizeBytes = img.total() * img.elemSize();

            ui->input_poids->setText(QString::number(static_cast<qulonglong>(imageSizeBytes)));

        }
        else
        {
            QMessageBox::warning(nullptr, "Attention","Le fichier sélectionné n'est pas valide où n'existe pas",QMessageBox::Ok);
        }
}

//! Bouton pour quitter l'interface
void FormModification::on_quit_btn_clicked()
{
    hide();
}

