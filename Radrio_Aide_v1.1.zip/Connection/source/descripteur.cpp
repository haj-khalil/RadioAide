#include "descripteur.h"

///! Construction d'un élément nul de type descripteur
descripteur::descripteur()
{
    _id_descripteur = 0;
    _titre = "None";
    _patient = "John";
    _technique = "None";
    _acces = "L";
    _cout = 0;
    _poids = 0;
    _source = "None";
    _taille = "0x 0";

    _lines = {
        std::to_string(_id_descripteur),
        _titre,
        _patient,
        _technique,
        _acces,
        std::to_string(_cout),
        std::to_string(_poids),
        _source,
        _taille
    };

    _path = ".";
}

// Constrruction d'un descripteur à partir d'un vecteur de lignes et d'un chemin vers le fichier texte
descripteur::descripteur(std::vector<std::string> lines,string path){
_id_descripteur = stoi(lines[0]);
_titre = lines[1].c_str();
_patient = lines[2].c_str();
_technique = lines[3].c_str();
_acces = (lines[4].c_str());
_cout = stof(lines[5]);
_poids =stol(lines[6]);
_source = lines[7].c_str();
_taille = lines[8];
_lines = lines;
_path = path;
}

//! Afficher les élément ddu descripteur
void descripteur::affiche(){
    cout<< "ID : "<<_id_descripteur<<"\n";
    cout<< "Tire : "<<_titre<<"\n";
    cout<< "Patient : "<<_patient<<"\n";
    cout<< "Technique : "<<_technique<<"\n";
    cout<< "Accès : "<<_acces<<"\n";
    cout<< "Cout : "<<_cout<<"\n";
    cout<< "Poids: "<<_poids<<"\n";
    cout<< "Source : "<<_source<<"\n";
    cout<< "Taille : "<<_taille<<"\n";
    cout<< endl;
}

//! Écrire les éléments du descripteur dans un fichier
void descripteur::writeToFile(const string &path) const
{
    fstream myFile;

    myFile.open(path, ios::out);

    if (myFile.is_open())
    {
        cout << _lines.size() << endl;
        for (int i = 0; i < _lines.size(); i++)
        {
            myFile << _lines[i] << endl;
            cout << "Line " << i << " : " << _lines[i] <<  endl;
        }
        myFile.close();
        cout << "Descripteur enregistré dans le fichier :  " << path << endl;
    }
    else
    {
        cout << "Erreur dans l'enregistrement du fichier vers :  " << path << endl;
    }

}

// Getters
int descripteur::getID()
{
    return _id_descripteur;
}

std::vector<string> descripteur::getLines()
{
    return _lines;
}

string descripteur::getPath()
{
    return _path;
}

float descripteur::getCout()
{
    return _cout;
}


// Setters
void  descripteur::setPath(string &path)
{
    _path = path;
}

void descripteur::setID(int &id)
{
    _id_descripteur = id;
    _lines[0] = to_string(id);
}

void descripteur::setTaille(string &taille)
{
    _taille = taille;
    _lines[8] = taille;
    cout << "Size updated : " << _lines[8] << endl;
}

void descripteur::setPoids(size_t &poids)
{
    _poids = poids;
    _lines[6] = to_string(poids);
    cout << "Poids updated : " << _lines[6] << endl;
}
