#include "mainwindow.h"
#include <QApplication>
#include "include.h"

int main(int argc, char *argv[])
{


    // Charger l'interface graphique de l'application
    QFile styleSheetFile("../Connection/Combinear/Combinear.qss");

    if (styleSheetFile.open(QFile::ReadOnly))
    {
        QApplication a(argc, argv);
        QString style = QLatin1String(styleSheetFile.readAll());
        a.setStyleSheet(style);

        MainWindow w;
        w.show();

        return a.exec();
    }
    else
    {
        // Gestion de l'erreur si le fichier de style ne peut pas être ouvert, ouverture de l'application avec l'interface de base
        qWarning("L'interface graphique modifiée n'a pas pu être chargé, ouverture de l'interface basique");

        QApplication a(argc, argv);
        MainWindow w;
        w.show();
        return a.exec();
    }
}
