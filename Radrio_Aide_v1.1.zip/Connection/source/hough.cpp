#include "hough.h"

#define DEG2RAD 0.017453293f // Converion des degrès en radian

namespace diff {

// Constructor
Hough::Hough() : _accu(nullptr), _accu_w(0), _accu_h(0), _img_w(0), _img_h(0) {}

//! Desctructor
Hough::~Hough() {
    if (_accu) {
        delete[] _accu;
    }
}

//! Calcul de la transformée de Hough à partir des éléments de l'image binarisée
int Hough::FctHough(unsigned char* img_data, int w, int h) {
    _img_w = w;
    _img_h = h;

    double hough_h = ((sqrt(HOUGH_H_SCALE) * std::max(h, w)) / HOUGH_H_SCALE );
    _accu_h = static_cast<int>(hough_h * HOUGH_H_SCALE );
    _accu_w = 180;

    _accu = new unsigned int[_accu_h * _accu_w]();

    double center_x = w / 2;
    double center_y = h / 2;// Bibliothèque Eigen pour les opérations mathématiques et matrices

    Eigen::MatrixXd cosTable(180, w);
    Eigen::MatrixXd sinTable(180, h);

    for (int t = 0; t < 180; ++t) {
        double angle = static_cast<double>(t) * DEG2RAD;
        cosTable.row(t) = ((Eigen::ArrayXd::LinSpaced(w, 0, w - 1).cast<double>() - center_x) * cos(angle)).transpose();
        sinTable.row(t) = ((Eigen::ArrayXd::LinSpaced(h, 0, h - 1).cast<double>() - center_y) * sin(angle)).transpose();
    }

    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            if (img_data[(y * w) + x] > 250) {
                for (int t = 0; t < 180; ++t) {
                    double r = cosTable(t, x) + sinTable(t, y);
                    _accu[static_cast<int>((round(r + hough_h) * 180.0)) + t]++;
                }
            }
        }
    }

    return 0;
}

//! Récupérer les lignes à tracer après la transformée de Hough
std::vector<std::pair<std::pair<int, int>, std::pair<int, int>>> Hough::GetLines(int threshold) {
    std::vector<std::pair<std::pair<int, int>, std::pair<int, int>>> lines;

    if (!_accu) {
        return lines;
    }

    for (int r = 0; r < _accu_h; ++r) {
        for (int t = 0; t < _accu_w; ++t) {
            if (static_cast<int>(_accu[(r * _accu_w) + t]) >= threshold) {
                int max = _accu[(r * _accu_w) + t];
                for (int ly = -MAX_NEIGHBORHOOD; ly <= MAX_NEIGHBORHOOD; ++ly) {
                    for (int lx = -MAX_NEIGHBORHOOD; lx <= MAX_NEIGHBORHOOD; ++lx) {
                        if ((ly + r >= 0 && ly + r < _accu_h) && (lx + t >= 0 && lx + t < _accu_w)) {
                            if (static_cast<int>(_accu[((r + ly) * _accu_w) + (t + lx)]) > max) {
                                max = _accu[((r + ly) * _accu_w) + (t + lx)];
                                ly = lx = MAX_NEIGHBORHOOD+1;
                            }
                        }
                    }
                }
                if (max > static_cast<int>(_accu[(r * _accu_w) + t])) {
                    continue;
                }

                int x1, y1, x2, y2;
                x1 = y1 = x2 = y2 = 0;

                if (t >= 45 && t <= 135) {
                    x1 = 0;
                    y1 = ((double)(r - (_accu_h / 2)) - ((x1 - (_img_w / 2)) * cos(t * DEG2RAD))) / sin(t * DEG2RAD) + (_img_h / 2);
                    x2 = _img_w - 0;
                    y2 = ((double)(r - (_accu_h / 2)) - ((x2 - (_img_w / 2)) * cos(t * DEG2RAD))) / sin(t * DEG2RAD) + (_img_h / 2);
                } else {
                    y1 = 0;
                    x1 = ((double)(r - (_accu_h / 2)) - ((y1 - (_img_h / 2)) * sin(t * DEG2RAD))) / cos(t * DEG2RAD) + (_img_w / 2);
                    y2 = _img_h - 0;
                    x2 = ((double)(r - (_accu_h / 2)) - ((y2 - (_img_h / 2)) * sin(t * DEG2RAD))) / cos(t * DEG2RAD) + (_img_w / 2);
                }

                lines.emplace_back(std::make_pair(x1, y1), std::make_pair(x2, y2));
            }
        }
    }

    std::cout << "lines: " << lines.size() << " " << threshold << std::endl;
    return lines;
}

const unsigned int* Hough::GetAccu(int* w, int* h) {
    *w = _accu_w;
    *h = _accu_h;

    return _accu;
}

}



