#include "imageeditor.h"
#include "ui_imageeditor.h"

QT_CHARTS_USE_NAMESPACE

//! Constructor avec l'image à modifier en entée l'image à modifier
ImageEditor::ImageEditor(Image image, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ImageEditor)
{
    ui->setupUi(this);
    _img = image;
    _img_bckp = image;

    QString path = QString::fromStdString(_img.getPath());

    // Afficher l'image initiale à droite de l'interface
    QPixmap myimg(path);
    ui->init_img_disp->setPixmap(myimg);
    ui->init_img_disp->setScaledContents(true);

    // Afficher les valeurs initiales des sliders
    QString size = QString::number(ui->gauss_size_slider->value());
    ui->gauss_size_disp->setText(size);

    QString intensity = QString::number(ui->gauss_intensity_slider->value());
    ui->gauss_intensity_disp->setText(intensity);
}

ImageEditor::~ImageEditor()
{
    delete ui;
}

//! Quitter la fenêtre
void ImageEditor::on_quit_btn_clicked()
{
    hide();
}

// -------------------------- GAUSS -------------------------- //

//! Changer dynamiquement la valeur afficher en fonction de la valeur sélectionnée pour la taille du filtre gaussien
void ImageEditor::on_gauss_size_slider_valueChanged(int value)
{
    // On veut que la taille du filtre soit impair
    if (value%2==0)
    {
        ui->gauss_size_slider->setValue(value+1);
        value++;
    }

    QString size = QString::number(value);
    ui->gauss_size_disp->setText(size);
}

//! Changer dynamiquement la valeur du paramètre sigma du filtre gaussien
void ImageEditor::on_gauss_intensity_slider_valueChanged(int value)
{
    QString intensity = QString::number(value/100, 'f', 2);
    ui->gauss_intensity_disp->setText(intensity);
}

//! Appliquer le filtre gaussien à l'image
void ImageEditor::on_apply_gauss_filter_clicked()
{
    Image mod_img = Image(_img.getPath(), _img.getMulticanal());
    int size = ui->gauss_size_slider->value();
    double sigma = ui->gauss_intensity_slider->value()/100;

    mod_img.applyGaussianBlur(size,sigma);

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    // Affichage de l'image
    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}

// -------------------------- MOYENNEUR -------------------------- //

//! Changer dynamiquement la valeur afficher en fonction de la valeur sélectionnée pour la taille du filtre moyenneur
void ImageEditor::on_moy_size_slider_valueChanged(int value)
{
    // On veut que la taille du filtre soit impair
    if (value%2==0)
    {
        ui->moy_size_slider->setValue(value+1);
        value++;
    }

    QString size = QString::number(value);
    ui->moy_size_disp->setText(size);
}

//! Application du filtre moyenneur
void ImageEditor::on_apply_moy_filter_clicked()
{
    Image mod_img = Image(_img.getPath(), _img.getMulticanal());
    int size = ui->moy_size_slider->value();

    mod_img.applyMoyFilter(size);

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    // Display the selected image
    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);  // Scale the image to fit the labe
}

// -------------------------- EXPONENTIEL -------------------------- //

//! Changer dynamiquement la valeur afficher en fonction de la valeur sélectionnée pour l'intensité du filtre flou exponentiel
void ImageEditor::on_exp_intensity_slider_valueChanged(int value)
{
    QString intensity = QString::number(value/100, 'f', 2);
    ui->exp_intensity_disp->setText(intensity);
}

//! Appliquer le filtre exponentiel
void ImageEditor::on_apply_exp_filter_clicked()
{
    QMessageBox::warning(this, "Attention","Cette fonctionalité n'est pas encore disponible");

    // TODO : résoudre l'erreur avec l'application du filtre

    /*
    Image mod_img = Image(_img.getPath(), _img.getMulticanal());
    int size = 3;
    double sigma = ui->exp_intensity_slider->value()/100;

    mod_img.applyExpFilter(size,sigma);

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    // Display the selected image
    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
    */
}



// -------------------------- NIVEAU DE GRIS -------------------------- //

//! Convertir l'image en niveaux de gris
void ImageEditor::on_greyscale_btn_toggled(bool checked)
{
    if (checked)
    {
        _img.GreyScale();

        string output_path = "../Connection/image/temp/temp_ndg.png";
        _img.setPath(output_path);

        _img.Save(output_path);
        QString path = QString::fromStdString(_img.getPath());

        QPixmap myimg(path);
        ui->init_img_disp->setPixmap(myimg);
        ui->init_img_disp->setScaledContents(true);
    }
    else
    {
        _img = _img_bckp;

        QString path = QString::fromStdString(_img.getPath());

        QPixmap myimg(path);
        ui->init_img_disp->setPixmap(myimg);
        ui->init_img_disp->setScaledContents(true);
    }

}

// -------------------------- HISTOGRAMMES -------------------------- //

//! Affichage des histogrammmes sur un objet de type QCharts
void ImageEditor::on_ChartPLot_clicked()
{
    auto histo = _img.Histogramme(ui->bins_count->value());
    auto& y_axis = histo[1];

    QBarSeries *barSeries = new QBarSeries();
    float width = (histo[0][1]-histo[0][0])/4;
    barSeries->setBarWidth(width);

    QBarSet *barSet = new QBarSet("Data Set");

    QBrush Brush(Qt::blue);
    barSet->setBrush(Brush);

    if (ui->canal_selection->currentIndex()==1){
        y_axis = histo[2];
        QBrush Brush(Qt::green);
        barSet->setBrush(Brush);
    }
    if (ui->canal_selection->currentIndex()==2){
        y_axis = histo[3];
        QBrush Brush(Qt::red);
        barSet->setBrush(Brush);
    }


    for (int i = 0; i < y_axis.size(); ++i) {
        *barSet << y_axis[i];
    }

    barSeries->append(barSet);

    QChart *chart = new QChart();
    chart->addSeries(barSeries);

    chart->setTitle("");
    chart->legend()->hide();

    // Paramètres de l'axe X
    QValueAxis *axisX = new QValueAxis();
    axisX->setRange(0, histo[0].size());
    axisX->setLabelFormat("%d");
    axisX->setTickCount(2);
    chart->addAxis(axisX, Qt::AlignBottom);
    barSeries->attachAxis(axisX);

    axisX->setLabelsVisible(false);

    // Paramètres de l'axe Y
    QValueAxis *axisY = new QValueAxis();
    chart->addAxis(axisY, Qt::AlignLeft);
    barSeries->attachAxis(axisY);


    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);


    QGraphicsView *plot = ui->plot;


    QSize plotSize = plot->viewport()->size();


    chartView->setMinimumSize(plotSize);

    QGraphicsScene *scene = new QGraphicsScene();
    scene->addWidget(chartView);
    plot->setScene(scene);


    scene->setSceneRect(chartView->rect());

    chartView->setMinimumSize(chartView->sizeHint());

    // Show the chart view
    chartView->show();

    Image mod_img = Image(_img.getPath(), _img.getMulticanal());

    int canal = ui->canal_selection->currentIndex();
    mod_img.IsolerCanal(canal);

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}

//! Actualiser l'affichage en fonction du canal choisi
void ImageEditor::on_canal_selection_currentIndexChanged(const QString &arg1)
{
    // Réactualiser l'affichage en appuyant virtuellement sur le bouton
    on_ChartPLot_clicked();
}

// -------------------------- FILTRES DERIVATIFS -------------------------- //

//! Application du filtre Laplacien
void ImageEditor::on_Laplacien_btn_clicked()
{
    Image mod_img = Image(_img.getPath(), _img.getMulticanal());

    mod_img.DetectContours();

    int seuil_bas = ui->select_low_threshold->value();
    int seuil_haut = ui->select_high_threshold->value();

    if (ui->Binarisation_check->isChecked()) mod_img.Binariser(seuil_bas, seuil_haut);

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    // Display the selected image
    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}

//! //! Application du filtre Gradient de type Sobel dans la direction horizontale
void ImageEditor::on_Sobel_hor_clicked()
{
    Image mod_img = Image(_img.getPath(), _img.getMulticanal());

    mod_img.DetectContoursGradientY();

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}

//! Application du filtre Gradient de type Sobel dans la direction verticale
void ImageEditor::on_Sobel_vert_clicked()
{
    Image mod_img = Image(_img.getPath(), _img.getMulticanal());

    mod_img.DetectContoursGradientX();

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}

//! Application du filtre Gradient de type Sobel
void ImageEditor::on_Sobel_btn_clicked()
{
    Image mod_img = Image(_img.getPath(), _img.getMulticanal());

    mod_img.DetectContoursGradient();

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}

//! Modification de l'affichage de la valeur du facteur d'augmentation de contours
void ImageEditor::on_contour_factor_slider_valueChanged(int value)
{
    QString intensity = QString::number(value/100, 'f', 2);
    ui->contour_factor_disp->setText(intensity);
}

//! Modification de l'affichage de la valeur de seuil pour l'augmentation de contour
void ImageEditor::on_threshold_slider_valueChanged(int value)
{
    QString thresh = QString::number(value);
    ui->threshold_disp->setText(thresh);
}

//! Application du rehaussement de contours
void ImageEditor::on_contour_enhance_btn_clicked()
{
    float alpha = ui->contour_factor_slider->value()/100;
    int threshold = ui->threshold_slider->value();

    Image mod_img = Image(_img.getPath(), _img.getMulticanal());

    mod_img.EnhanceContoursLaplacian(alpha, threshold);

    string output_path = "../Connection/image/temp/temp.png";

    mod_img.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    // Display the selected image
    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}


// -------------------------- TRANSFORM HOUGH -------------------------- //

//! Application de la transformée de Hough par détection de contours en utlisant la fonction Canny de OpenCV
void ImageEditor::on_Hough_transform_canny_btn_clicked()
{
    int threshold =ui->hough_threshold_slider->value();
    string img_path = _img.getPath();

    int R =  ui->Rouge_slider->value();
    int G =  ui->Vert_slider->value();
    int B =  ui->Bleu_slider->value();

    vector<int> RGB = {R, G, B};

    doFctHoughCanny(img_path, threshold, RGB);
}

//! Application de la transformée de Hough en utilisant le gradient de Sobel seuillé pour détecter les contours
void ImageEditor::on_Hough_transform_btn_clicked()
{
    int threshold =ui->hough_threshold_slider_2->value();
    string img_path = _img.getPath();

    int R =  ui->Rouge_slider->value();
    int G =  ui->Vert_slider->value();
    int B =  ui->Bleu_slider->value();

    vector<int> RGB = {R, G, B};

    int size = ui->hough_gauss_size_slider->value();
    float intensity = ui->hough_gauss_intensity_slider->value()/100;

    int seuil_bas = ui->seuil_bas_box->value();
    int seuil_haut = ui->seuil_haut_box->value();

    int method = ui->select_contours_detect->currentIndex();

    doFctHough(img_path, threshold, size, intensity, seuil_bas, seuil_haut, RGB, method);
}

//! Fonction transformée de Hough pour détection de Canny
void ImageEditor::doFctHoughCanny(std::string file_path, int threshold, vector<int> RGB)
{
    cv::Mat img_edge;
    cv::Mat img_blur;

    cv::Mat img_ori = cv::imread( file_path, 1 );
    cv::blur( img_ori, img_blur, cv::Size(5,5) );
    cv::Canny(img_blur, img_edge, 100, 150, 3);

    int w = img_edge.cols;
    int h = img_edge.rows;

    // Transformée
    diff::Hough hough;
    hough.FctHough(img_edge.data, w, h);


    cv::Mat img_res = img_ori.clone();

    std::vector< std::pair< std::pair<int, int>, std::pair<int, int> > > lines = hough.GetLines(threshold);

    std::vector< std::pair< std::pair<int, int>, std::pair<int, int> > >::iterator it;
    for(it=lines.begin();it!=lines.end();it++)
    {
        cv::line(img_res, cv::Point(it->first.first, it->first.second), cv::Point(it->second.first, it->second.second), cv::Scalar( RGB[2], RGB[1], RGB[0]), 2, 8);
    }

    //! Sauvegarder l'image et afficher dans l'interface
    string output_path = "../Connection/image/temp/temp.png";

    imwrite(output_path,img_res);

    QString output_path_qt = QString::fromStdString(output_path);

    // Afficher l'image
    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);

}

//! Fonction de transformée de Hough pour détection de Sobel
void ImageEditor::doFctHough(std::string file_path, int threshold, int size, float intensity, int seuil_bas, int seuil_haut, vector<int> RGB, int method)
{
    Image img_hough = Image(_img.getPath(),true);

    img_hough.applyGaussianBlur(size, intensity);

    if (method==0) {
    // Application gradient Solbel
    img_hough.DetectContoursGradient();
    }
    else {
    //  Application gradient Laplacien
    img_hough.DetectContours();
    }

    img_hough.Binariser(seuil_bas, seuil_haut);

    int w = img_hough.getSize()[1];
    int h = img_hough.getSize()[0];

    //Transform
    diff::Hough hough;
    hough.FctHough(img_hough.getImage().data, w, h);

    Image img_res = Image(_img.getPath(),true);

    std::vector< std::pair< std::pair<int, int>, std::pair<int, int> > > lines = hough.GetLines(threshold);

    std::vector< std::pair< std::pair<int, int>, std::pair<int, int> > >::iterator it;
    for(it=lines.begin();it!=lines.end();it++)
    {
        cv::line(img_res.getImage(), cv::Point(it->first.first, it->first.second), cv::Point(it->second.first, it->second.second), cv::Scalar( RGB[2], RGB[1], RGB[0]), 2, 8);
    }

    // Sauvegarder l'image et afficher dans l'interface
    string output_path = "../Connection/image/temp/temp.png";

    img_res.Save(output_path);

    QString output_path_qt = QString::fromStdString(output_path);

    // Afficher l'image
    QPixmap mod_img_disp(output_path_qt);
    ui->modified_img_disp->setPixmap(mod_img_disp);
    ui->modified_img_disp->setScaledContents(true);
}

//! Modification de l'affichage de la valeur de la taille du filtre gaussien avant l'application de la transformée de Hough à détection de contours par la méthode du gradient de Sobel
void ImageEditor::on_hough_gauss_size_slider_valueChanged(int value)
{
    // On veut que la taille du filtre soit impair
    if (value%2==0)
    {
        ui->hough_gauss_size_slider->setValue(value+1);
        value++;
    }

    QString size = QString::number(value);
    ui->hough_gauss_size_disp->setText(size);
}

//! Modification de l'affichage de la valeur de l'inttensité du filtre gaussien avant l'application de la transformée de Hough à détection de contours par la méthode du gradient de Sobel
void ImageEditor::on_hough_gauss_intensity_slider_valueChanged(int value)
{
    ui->hough_gauss_intensity_disp->setText(QString::number(value/100, 'f', 2));
}

//! Modification de l'affichage de la valeur du canal rouge pour la couleur des lignes
void ImageEditor::on_Rouge_slider_valueChanged(int value)
{
    ui->Rouge_disp->setText(QString::number(value));

    display_color3();
}

//! Modification de l'affichage de la valeur du canal vert pour la couleur des lignes
void ImageEditor::on_Vert_slider_valueChanged(int value)
{
    ui->Vert_disp->setText(QString::number(value));

    display_color3();
}

//! Modification de l'affichage de la valeur du canal bleu pour la couleur des lignes
void ImageEditor::on_Bleu_slider_valueChanged(int value)
{
    ui->Bleu_disp->setText(QString::number(value));

    display_color3();
}

//! Modification de l'affichage de la couleur des lignes tracées
void ImageEditor::display_color3()
{
    int R = ui->Rouge_slider->value();
    int G = ui->Vert_slider->value();
    int B = ui->Bleu_slider->value();

    // Créer une image de type QImage d'un seul pixel
    QImage image(1, 1, QImage::Format_RGB32);
    image.setPixel(0, 0, qRgb(R, G, B));

    QPixmap color3 = QPixmap::fromImage(image);

    ui->color_selected_3->setPixmap(color3);
    ui->color_selected_3->setScaledContents(true);
}


// -------------------------- SEGMENTATION COULEURS -------------------------- //

//! Application d'un seuillage couleur sur l'image dans l'espace HSV
void ImageEditor::on_segColor_btn_clicked()
{

       int hue1 = ui->H_slider->value();
       int hue2 = ui->H_slider_2->value();
       int saturation1 = ui->S_slider->value();
       int saturation2 = ui->S_slider_2->value();
       int value1 = ui->V_slider->value();
       int value2 = ui->V_slider_2->value();


       Scalar yellowLow =Scalar(hue1 , saturation1,value1);
       Scalar yellowHigh =Scalar(hue2,saturation2,value2);
       // Corrige les valeurs de HSV si les composantes de la  couleur 1 sont plus grandes que celles de la couleur 2
       if(hue1>hue2 || saturation1>saturation2 || value1>value2){
            QMessageBox::warning(this, "Valeurs non valides","Les composantes de la couleur 1 doivent être inférieures à celles de la couleur 2");
       }
       else
       {

          Mat image = imread(_img.getPath());

          Mat copy , res , mask;
          image.copyTo(copy);
          image.copyTo(res);

          // afficher selement les contours sur white backgrund
          for (int y = 0; y < res.rows; ++y) {
              for (int x = 0; x < res.cols; ++x) {
                 cv::Vec3b& pixel = res.at<cv::Vec3b>(y, x);

                  pixel[0] = 255;
                   pixel[1] = 255;
                  pixel[2] = 255;
              }
           }

          // Convertir RGB en HSV
          cvtColor(image,image , COLOR_BGR2HSV);
          // Seuiller l'image
          inRange(image , yellowLow ,yellowHigh , mask );

           int R = ui->Rouge_seg_slider->value();
           int V = ui->Vert_seg_slider->value();
           int B = ui->Bleu_seg_slider->value();

           vector<vector<Point>> contour;
           findContours(mask , contour , RETR_EXTERNAL,CHAIN_APPROX_SIMPLE);
           drawContours(copy , contour , -1,cv::Scalar(B, V, R),3);
           drawContours(res , contour , -1,cv::Scalar(B, V, R),3);


           // Sauvegarder l'image pour l'affichage
           string output_path = "../Connection/image/temp/temp.png";

           if (ui->choix_affichage->currentIndex()==0) imwrite(output_path,mask);
           if (ui->choix_affichage->currentIndex()==1) imwrite(output_path,res);
           if (ui->choix_affichage->currentIndex()==2) imwrite(output_path,copy);

           QString output_path_qt = QString::fromStdString(output_path);

           QPixmap mod_img_disp(output_path_qt);
           ui->modified_img_disp->setPixmap(mod_img_disp);
           ui->modified_img_disp->setScaledContents(true);
       }

}

//! Modification de l'affichage de la valeur du canal rouge pour la couleur du contour de la segmentation
void ImageEditor::on_Rouge_seg_slider_valueChanged(int value)
{
    ui->Rouge_seg_disp->setText(QString::number(value));

    display_color4();
}

//! Modification de l'affichage de la valeur du canal vert pour la couleur du contour de la segmentation
void ImageEditor::on_Vert_seg_slider_valueChanged(int value)
{
    ui->Vert_seg_disp->setText(QString::number(value));

    display_color4();
}

//! Modification de l'affichage de la valeur du canal bleu pour la couleur du contour de la segmentation
void ImageEditor::on_Bleu_seg_slider_valueChanged(int value)
{
    ui->Bleu_seg_disp->setText(QString::number(value));

    display_color4();
}

//! Affichage de la couleur du contour
void ImageEditor::display_color4()
{
    int R = ui->Rouge_seg_slider->value();
    int G = ui->Vert_seg_slider->value();
    int B = ui->Bleu_seg_slider->value();

    QImage image(1, 1, QImage::Format_RGB32);
    image.setPixel(0, 0, qRgb(R, G, B));

    QPixmap color4 = QPixmap::fromImage(image);

    ui->color_selected_4->setPixmap(color4);
    ui->color_selected_4->setScaledContents(true);
}

//! Affichage de la couleur de seuil bas de la segmentation
void ImageEditor::display_color()
{
    int H = ui->H_slider->value();
    int S = ui->S_slider->value();
    int V = ui->V_slider->value();

    cv::Scalar hsv = cv::Scalar(H, S, V);

    cv::Mat bgr;
    cv::cvtColor(cv::Mat(1, 1, CV_8UC3, hsv), bgr, cv::COLOR_HSV2BGR);

    cv::Scalar rgb = bgr.at<cv::Vec3b>(0, 0);

    int R = rgb[2];
    int G = rgb[1];
    int B = rgb[0];

    QImage image(1, 1, QImage::Format_RGB32);
    image.setPixel(0, 0, qRgb(R, G, B));

    QPixmap color1 = QPixmap::fromImage(image);

    ui->color_selected->setPixmap(color1);
    ui->color_selected->setScaledContents(true);
}

//! Affichage de al couleur du seuil haut de la segmentation
void ImageEditor::display_color2()
{
    int H = ui->H_slider_2->value();
    int S = ui->S_slider_2->value();
    int V = ui->V_slider_2->value();

    cv::Scalar hsv = cv::Scalar(H, S, V);

    cv::Mat bgr;
    cv::cvtColor(cv::Mat(1, 1, CV_8UC3, hsv), bgr, cv::COLOR_HSV2BGR);

    cv::Scalar rgb = bgr.at<cv::Vec3b>(0, 0);

    int R = rgb[2];
    int G = rgb[1];
    int B = rgb[0];

    QImage image(1, 1, QImage::Format_RGB32);
    image.setPixel(0, 0, qRgb(R, G, B));

    QPixmap color2 = QPixmap::fromImage(image);

    ui->color_selected_2->setPixmap(color2);
    ui->color_selected_2->setScaledContents(true);
}

//! Modification de l'affichage de la valeur du canal hue pour la couleur du seuil bas
void ImageEditor::on_H_slider_valueChanged(int value)
{
    ui->H_disp->setText(QString::number(value));

    display_color();
}

//! Modification de l'affichage de la valeur du canal saturation pour la couleur du seuil bas
void ImageEditor::on_S_slider_valueChanged(int value)
{
    ui->S_disp->setText(QString::number(value));

    display_color();
}

//! Modification de l'affichage de la valeur du canal value pour la couleur du seuil bas
void ImageEditor::on_V_slider_valueChanged(int value)
{
    ui->V_disp->setText(QString::number(value));

    display_color();
}

//! Modification de l'affichage de la valeur du canal hue pour la couleur du seuil haut
void ImageEditor::on_H_slider_2_valueChanged(int value)
{
    ui->H_disp_2->setText(QString::number(value));

    display_color2();
}

//! Modification de l'affichage de la valeur du canal saturation pour la couleur du seuil haut
void ImageEditor::on_S_slider_2_valueChanged(int value)
{
    ui->S_disp_2->setText(QString::number(value));

    display_color2();
}

//! Modification de l'affichage de la valeur du canal value pour la couleur du seuil haut
void ImageEditor::on_V_slider_2_valueChanged(int value)
{
    ui->V_disp_2->setText(QString::number(value));

    display_color2();
}


//! Bouton pour sauvegarder les images après traitement
void ImageEditor::on_save_btn_clicked()
{
    QMessageBox::StandardButton reponse ;
    reponse = QMessageBox::question(this,"Sauvegarde", "Voulez-vous sauvegarder l'image modifiée ? ",QMessageBox::Yes |QMessageBox::No );

    if(reponse==QMessageBox::Yes){

        try {
            string output_path = "../Connection/image/temp/temp.png";
            Image img = Image(output_path,true);

            img.Save(_img.getPath());


            hide() ;

        }  catch (const std::exception& e) {
            QMessageBox::warning(this, "Attention", QString("L'image finale n'a pas pu être sauvegardée"));
        }


    }
}

