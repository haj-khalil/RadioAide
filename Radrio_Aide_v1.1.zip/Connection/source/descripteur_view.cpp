#include "descripteur_view.h"
#include "ui_descripteur_view.h"
#include "login.h"
#include "formmodification.h"
#include "uploadimage.h"
#include "imageeditor.h"
#include "include.h"

// Constructor de l'interface graphique de la fenêtre princiapel (affichage des données et menu vers les autres fenêtre)
Descripteur_view::Descripteur_view(User user, QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Descripteur_view)
{
    ui->setupUi(this);

    // Nettoyer les fichiers de l'actuelle bibliothèques
    _data.cleanData();

    // Rendre la zone de recherche éditable
    ui->search_item->setReadOnly(false);

    // Définir la taille de la police
    QFont font = ui->Descriptor_list->font();
    font.setPointSize(10);
    ui->Descriptor_list->setFont(font);

    cout << "Début du chargement" << endl;
    ui->Descriptor_list->update();
    ui->Descriptor_list->repaint();
    cout << "Fin du chargement" << endl;

    // Renseigner l'utilisateur
    _user = User(user.getRole(), user.getUsername());

    // Choix de charger ou non une bibliothèque par défaut
    QMessageBox::StandardButton reponse ;
    reponse = QMessageBox::question(this,"Initialisation", "Voulez-vous charger la bibliothèque de référence ? ",QMessageBox::Yes |QMessageBox::No );
    if(reponse==QMessageBox::Yes){
        copyFolder("../Connection/bib_ref/image/", "../Connection/image/");
        copyFolder("../Connection/bib_ref/descripteur/", "../Connection/descripteur/");
    }

    // Charger les données (descripteurs + images)
    string img_path = "../Connection/image";
    string desc_path = "../Connection/descripteur";

    _data = Data(img_path, desc_path);
    _data.triID(false);
    loaddata();
}

//! Desctuctor
Descripteur_view::~Descripteur_view()
{
    delete ui;
}

//! Lecture des fichiers dans les répertoires /Connection/descripteur/ et /Connection/image/ et affichage dans le tableau
void Descripteur_view::loaddata()
{
    int j=0, cpt =0;

    // Fixer le nombre de lignes du tableau en fonction du nombre de descripteurs à afficher
     ui->Descriptor_list->setRowCount(_data.getDescSize());
     ui->Descriptor_list->setColumnWidth(0,5);
     ui->Descriptor_list->setColumnWidth(4,80);
     ui->Descriptor_list->setColumnWidth(7,200);
     ui->Descriptor_list->setColumnWidth(9,80);
     ui->Descriptor_list->setColumnWidth(9,95);
     ui->Descriptor_list->setColumnWidth(10,80);

    // Boucle sur les éléments des données
    for (int i = 0 ; i< _data.getDescSize() ; i++){

        int id_access = 4;

        // N'afficher que les images libres de droit pour les utilisateurs de niveau 0
        if ((_user.getRole() == 0 && _data.get(id_access,i)=="L") | (_user.getRole() == 1) ) {

            j = 0;;

            // Affichage des éléments de la ligne
            for (int k=0; k<9; k++){

                string element = _data.get(j, i);

                QTableWidgetItem* item = new QTableWidgetItem(QString::fromStdString(element));
                item->setTextAlignment(Qt::AlignCenter);
                ui->Descriptor_list->setItem(i-cpt, j, item);

                j +=1;
            }

            // Création de la case d'affichage
            QTableWidgetItem *item = new QTableWidgetItem;
            QIcon icon("../Connection/icons/loupe.png");
            item->setIcon(icon);
            item->setTextAlignment(Qt::AlignCenter);
            ui->Descriptor_list->setItem(i-cpt, 9, item);

            // Création de la case d'édition
            QTableWidgetItem *item_e = new QTableWidgetItem;
            QIcon icon_e("../Connection/icons/modify.png");
            item_e->setIcon(icon_e);
            item_e->setTextAlignment(Qt::AlignCenter);
            ui->Descriptor_list->setItem(i-cpt, 10, item_e);

            // Création de la case de suppresion
            QTableWidgetItem *item_s = new QTableWidgetItem;
            QIcon icon_s("../Connection/icons/dustbin_red.png");
            item_s->setIcon(icon_s);
            item_s->setTextAlignment(Qt::AlignCenter);
            ui->Descriptor_list->setItem(i-cpt, 11, item_s);

        }
        // Compteur du nombre de lignes non affichées
        else
        {
            cpt++;
        }
    }
}

//! Mettre à jour les éléments du tableau de données
void Descripteur_view::on_pushButton_clicked()
{
    updatedesc();
    loaddata();
}

//! Fonction pour gérer l'édition de descripteur ou l'affichage / édition / suppresion d'une image associée en fonction de la colonne et la ligne du tableau sur laquelle est effectuée un double clique
void Descripteur_view::on_Descriptor_list_cellDoubleClicked(int row, int column)
{
      std::vector<QString> info;
      int cond = _user.getRole();

      switch (cond)
      {
        case 1 :


      // Cas de l'affichage d'une image
      if (column==9){
           string path = _data.getImg(row).getPath();

           cout << "[AFFICHER] affichage du chemin : " << path << endl;

           QString path_qt = QString::fromStdString(path);
           QPixmap mod_img_disp(path_qt);
           ui->image_disp->setPixmap(mod_img_disp);
           ui->image_disp->setScaledContents(true);
       }
      // Cas de l'édition d'une image
      else if (column == 10){
          Image myimg = _data.getImg(row);

          imageeditor = new ImageEditor(myimg ,nullptr);
          imageeditor->show();
      }
      // Cas de la suppression d'une image / descripteur
      else if (column == 11){
          QMessageBox::StandardButton reponse ;
          reponse = QMessageBox::question(this,"Confirmation Message", "Voulez-vous supprimer cette ligne ? ",QMessageBox::Yes |QMessageBox::No );

          if(reponse==QMessageBox::Yes){
                _data.deleteElem(row);
                loaddata();
          }
      }
      // Cas de la modification d'une ligne des données
      else{
          if (row >= 0 && row < ui->Descriptor_list->rowCount()) {

                for (int col = 0; col < ui->Descriptor_list->columnCount(); col++) {
                    QTableWidgetItem *item = ui->Descriptor_list->item(row, col);
                    if (item) {
                        QString cellText = item->text();
                        info.push_back(cellText);
                        qDebug() << "Colonne " << col << ": " << cellText;

                    }
                }
            }

          info.push_back(QString::number(row));

          Image img = _data.getImg(row);
          formModification = new FormModification(_data.getDesc(row), img, nullptr);

          formModification->InfoModification(info);
          formModification->show();
      }
          break;

      case 0  :
          // Cas de l'affichage d'une image - On autorise les utilisateur de niveau 0 à voir les images marquée 'L'
          if (column==9){
               string path = _data.getImg(row).getPath();

               cout << "[AFFICHER] affichage du chemin : " << path << endl;

               // Afficher une image dans un QLabel en utilisant le chemin vers l'image à afficher
               QString path_qt = QString::fromStdString(path);
               QPixmap mod_img_disp(path_qt);
               ui->image_disp->setPixmap(mod_img_disp);
               ui->image_disp->setScaledContents(true);
           }
           else  QMessageBox::warning(this,"Permission refusée","Vous n'avez pas les droits pour effectuer cette action"); break;

      default : QMessageBox::warning(this,"Permission refusée","Votre niveau d'accès n'a pas été reconnu");

      }
}

//! Ouverture de la fenêtre d'ajout d'un nouvel élément à la base de donnée
void Descripteur_view::on_ptn_new_image_clicked()
{

    int cond = _user.getRole();


    // Vérifier que l'utilisateur possède les droit d'édition de la bibliothèque
    if (cond){
        if (_data.getDescSize()==0){
            QMessageBox::warning(this,"Attention","Impossible d'ajouter une image quand la bibliothèque est vide, création d'un élément vierge à la place");
            descripteur desc = descripteur();
            Image img = Image();

            int ID = 1;
            img.setID(ID);
            desc.setID(ID);

            img.Save("../Connection/image/1.png");
            desc.writeToFile("../Connection/descripteur/1.txt");

            _data.addElem(img, desc);
            loaddata();
        }
        else
        {
            uploadimage = new UploadImage(nullptr);

            uploadimage->show();
            on_reload_btn_clicked();
        }
    }
    else QMessageBox::warning(this,"Permission refusée","Vous n'avez pas les droits pour effectuer cette action");
}

//! Tri en fonction de l'ID (croissant)
void Descripteur_view::on_Tri_ID_clicked()
{
    _data.triID(false);
    updatedesc();
    loaddata();
}

//! Tri en fonction du cout (croissant)
void Descripteur_view::on_btn_tri_cout_clicked()
{
    _data.triCout(false);
    updatedesc();
    loaddata();
}

//! Fonction pour mettre à jour les données des descripteurs en recréer des nouveaux descripteurs qui seront assigné aux données
void Descripteur_view::updatedesc()
{
    for(int i=0; i<_data.getDescSize();i++)
    {
        auto path = _data.getDesc(i).getPath();
        std::vector<string> lines = Login::file_to_lines(path,0);
        _data.getDesc(i) = descripteur(lines, path);
    }
}

//! Charger une nouvelle fois les données en recréant un  objet  Donnés par lectures des fichiers dans les chemins /Connection/image/ et /Connection/descripteur/
void Descripteur_view::on_reload_btn_clicked()
{
    // Charger les données (descripteurs + images)
    string img_path = "../Connection/image";
    string desc_path = "../Connection/descripteur";

    _data = Data(img_path, desc_path);
    loaddata();
}

//! Exporter la bibliothèque actuelle vers un fichier
void Descripteur_view::on_export_btn_clicked()
{
    try {
        QString directoryPath = QFileDialog::getExistingDirectory(this, tr("Choisir un dossier"), QCoreApplication::applicationDirPath());
        string path = directoryPath.toStdString();
        _data.exportData(path);
    }  catch (std::exception& e) {
        QString msg = QString::fromStdString("Erreur lors de l'enregistrement des données : "+string(e.what()));
        QMessageBox::warning(this,"Erreur",msg);
    }
}

//! Charger une bibliothèque existante, une bibliothèque est un dossier qui contient deux sous-dossier "image" et "descripteur" qui seront les seuls à être lus
void Descripteur_view::on_load_btn_clicked()
{
    try {

        QString directoryPath = QFileDialog::getExistingDirectory(this, tr("Choisir un dossier"), QCoreApplication::applicationDirPath());
        string path = directoryPath.toStdString();

        string img_path = path+"/image";

        string desc_path = path+"/descripteur";

        // Vérifier l'existence d'un dossier /image
        if (!boost::filesystem::exists(img_path)) {
            throw std::runtime_error("Le dossier /image n'existe pas dans le chemin spécifié.");
        }

        // Vérifier l'existence d'un dossier /descripteur
        if (!boost::filesystem::exists(desc_path)) {
            throw std::runtime_error("Le dossier /descripteur n'existe pas dans le chemin spécifié.");
        }

        // Nettoyer les fichiers de l'actuelle bibliothèques
        _data.cleanData();

        copyFolder(img_path, "../Connection/image/");
        copyFolder(desc_path, "../Connection/descripteur/");

        string path_img = "../Connection/image/";
        string Acces = "Accès";
        string path_desc = "../Connection/descripteur/";
        _data = Data(path_img, path_desc);


    }  catch (std::exception& e) {
        QString msg = QString::fromStdString("Erreur lors du chargement des données : "+string(e.what()));
        QMessageBox::warning(this,"Erreur",msg);
    }

    // Appuyer virtuellement sur le bouton reload pour recharger les données
    Descripteur_view::on_reload_btn_clicked();
}

//! Copier les éléments d'une dossier vers un second
void Descripteur_view::copyFolder(const std::string& sourceDir, const std::string& destDir) {
    try {
        // Créer le dossier de destination s'il n'existe pas
        if (!boost::filesystem::exists(destDir)) {
            boost::filesystem::create_directory(destDir);
        }

        // Boucle sur les éléments du dossier
        for (const auto& entry : boost::filesystem::directory_iterator(sourceDir)) {
            // Vérifier le type de fichier
            if (boost::filesystem::is_regular_file(entry)) {

                boost::filesystem::path destPath = destDir;
                destPath /= entry.path().filename();

                // Copie des fichiers
                boost::filesystem::copy_file(entry.path(), destPath);
            }
        }

        std::cout << "Copie des fichiers effectuée." << std::endl;
    } catch (const boost::filesystem::filesystem_error& e) {
        std::cerr << "Erreur lors de la copie: " << e.what() << std::endl;
    }
}

//! Réinitialiser la recherche et faire apparaître tout les descripteurs
void Descripteur_view::on_reset_btn_clicked()
{
    // Charger les données (descripteurs + images)
    string img_path = "../Connection/image";
    string desc_path = "../Connection/descripteur";

    _data = Data(img_path, desc_path);
    loaddata();
}

//! Fonction pour trouver un élément de recherche dans la base de données
void Descripteur_view::on_search_btn_clicked()
{
    string word = ui->search_item->text().toStdString();

    string text = ui->searchIn->currentText().toStdString();
    string ID = "ID";
    string Titre = "Titre";
    string Patient = "Patient";
    string Technique = "Technique";
    string Acces = "Accès";
    string Source = "Source";

    int col;

    if (text == ID) col = 0;
    if (text == Titre) col = 1;
    if (text == Patient) col = 2;
    if (text == Technique) col = 3;
    if (text == Acces) col = 4;
    if (text == Source) col = 7;

    cout << _data.getDescSize() << " ID to compare : " << col << endl;
    _data.triID(false);

    std::vector<int> tosuppr;

    for (int i=0; i<_data.getDescSize(); i++)
    {
        size_t found = string(_data.get(col, i)).find(word);
        cout << _data.get(col, i) ;
        // Si on ne trouve pas la chaîne de caractère alors l'élément doit être supprimé
        if (found == std::string::npos) {
            tosuppr.push_back(i);
            cout << " *";
        }
        cout << endl;
    }

    for (int j=0; j<tosuppr.size(); j++)
    {
        _data.deleteElem(tosuppr[j]-j);
    }

    updatedesc();
    loaddata();
}

//! Tri en fonction de l'ID (décroissant)
void Descripteur_view::on_Tri_ID_dec_clicked()
{
    _data.triID(true);
    updatedesc();
    loaddata();
}

//! Tri en fonction du coût (décroissant)
void Descripteur_view::on_btn_tri_cout_dec_clicked()
{
    _data.triCout(true);
    updatedesc();
    loaddata();
}

//! Affichage conditionnel des éléments des données en fonction du prix
void Descripteur_view::on_condition_show_btn_clicked()
{
    float inf = ui->inf_born->value();
    float sup = ui->sup_born->value();

    _data.tri_conditionnel(inf, sup);
    updatedesc();
    loaddata();
}


//! Création de données statistiques de base sur les éléments des données
std::vector<float> Descripteur_view::stat_cout(){
    std::vector<float> prices ;
    int R = 0;
    float   sum = 0;
    std::vector<string>  file_list=  Login::file_list();


    for(int i =0 ; i<_data.getDescSize() ;i++){

        float price = stof(_data.getDesc(i).getLines()[5]);
        prices.push_back(price);
        sum +=price ;
        if(_data.getDesc(i).getLines()[4]=="R") R++;

    }

    float moy  = sum / 5;
    float max =  prices[0];
    float min =prices[0];
    for(int i =0 ; i<prices.size() ;i++){
        if(prices[i]>max)max=prices[i];
        if(prices[i]<max)min=prices[i];
    }

    std::vector<float> res ;
    res.push_back(_data.getDescSize());
    res.push_back(moy);
    res.push_back(max);
    res.push_back(min);
    res.push_back(R);
    res.push_back(_data.getDescSize()-R);

    return res;
}

//! Affichage des statistiques
void Descripteur_view::on_stat_btn_clicked()
{
    if (_data.getDescSize()==0){
        QMessageBox::warning(this,"Attention","Aucuns éléments dans la bibliothèque, les statistiques ne peuvent pas être estimées");
    }
    else
    {
        auto info = Descripteur_view::stat_cout();
        QString statistic = " Images : " + QString::number(info[0])+ "\n Coût moyen :"+QString::number(info[1])+" €\n Coût max : "+QString::number(info[2])
               +" €\n Coût min : "+QString::number(info[3])+" €\n Images privées :"+QString::number(info[4])+
               "\n Images libres : "+QString::number(info[5]);
        ui->statistic->setText(statistic);
    }

}
