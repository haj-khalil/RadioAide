#include "mainwindow.h"
#include "./ui_mainwindow.h"

//! Constructor
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
     ui->setupUi(this);
    QPixmap mod_img_disp("../Connection/icons/Radio_Aide.png");

    int decalageX = static_cast<int>(mod_img_disp.width() * 0.90);
    QPixmap pixmapDecalee(mod_img_disp.width() + decalageX, mod_img_disp.height());
    pixmapDecalee.fill(Qt::transparent);
    QPainter painter(&pixmapDecalee);
    painter.drawPixmap(decalageX, 0, mod_img_disp);
    ui->logo->setPixmap(pixmapDecalee);
    ui->logo->setFixedSize(200, 100);
    ui->logo->setScaledContents(true);
}

//!  Desctructor
MainWindow::~MainWindow()
{
    delete ui;
}

//! Lancer le processus d'authefication lorsque le bouton de connection est apppuyé
void MainWindow::on_btn_connection_clicked()
{
    string username = ui->edt_usr->text().toStdString();
    string password = ui->edt_mdp->text().toStdString();

    bool success=0;

    // Création d'une classe login pour simplifier le code
    Login test_login = Login();

    success = test_login.login_test(username, password);
    if (success){
        QMessageBox::information(this,"Identificarion réussie","Bienvenue dans Radio-Aide !");
        hide();

        // Récupérer le role de l'utilisateur
        int role = test_login.getUserRole(username);

        // Ouverture d'une fenêtre secondaire
        User utilisateur = User(role,username);

        descripteur_view = new Descripteur_view(utilisateur, this);
        descripteur_view->show();
    }


    else{
        QMessageBox::warning(this,"Échec de l'authentification","Mauvais mot de passe ou identifiant");
    }
}
