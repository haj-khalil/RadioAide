#include "image.h"

//! Constructors à partir d'un chemin vers une image et si cette dernière est en mono ou multi canal (non-utilisé pour le moment)
Image::Image(std::string path, bool multicanal)
{
    _image = cv::imread(path);
    _multicanal = true;
    _taille.resize(2);
    _taille[0] = _image.rows;
    _taille[1] = _image.cols;
    _path = path;

    try {
        // Find the position of the last '/' and the dot '.'
        size_t lastSlashPos = path.find_last_of('/');
        size_t dotPos = path.find_last_of('.');

        // Extract the substring between the last '/' and the dot '.'
        std::string id_s = path.substr(lastSlashPos + 1, dotPos - lastSlashPos - 1);

        _ID = stoi(id_s);
    }  catch (std::exception& e) {
        cout << "Le numéro d'ID n'a pas pu êtimé à partir du titre de l'image, un numéro quelconque à donc été choisi." << endl;
        _ID = 0;
    }
}

//! Construction de l'élement neutre d'Image
Image::Image()
{
    _image = cv::Mat(30, 30, CV_8UC3, cv::Scalar(0, 0, 0));
    _multicanal = true;
    _taille.resize(2);
    _taille[0] = _image.rows;
    _taille[1] = _image.cols;
    _path = "";
    _ID = 0;
}

// Getters
cv::Mat Image::getImage()
{
    return _image;
}

std::vector<int> Image::getSize()
{
    return _taille;
}

bool Image::getMulticanal()
{
    return _multicanal;
}

string Image::getPath()
{
    return _path;
}

int Image::getID()
{
    return _ID;
}

string Image::getSizeStr()
{
    string SizeStr = to_string(_taille[0]) + " x " + to_string(_taille[1]);
    return SizeStr;
}

// Setters
void Image::setImage(cv::Mat img)
{
    _image = img;
    _taille[0] = _image.rows;
    _taille[1] = _image.cols;
}

void Image::setMulticanal(bool multicanal)
{
    _multicanal = multicanal;
}

void Image::setID(int ID)
{
    _ID = ID;
}

void Image::setPath(string &path)
{
    _path = path;
}

// Methods
//! Afficher une image dans une fênetre à part
void Image::Afficher()
{
// Ajouter fonctionalité pour modifier la taille de la fenêtre
    cv::namedWindow("Affichage de l'image", cv::WINDOW_AUTOSIZE);
    cv::imshow("Affichage de l'image", _image);
    cv::moveWindow("Affichage de l'image", 0, 45);
    cv::waitKey(0);
    cv::destroyAllWindows();
}

//! Sauvegarder l'image dans un fichier
void Image::Save(const string& path) const {
    // Vérifier que l'image existe
    if (_image.empty()) {
        std::cerr << "Erreur : l'image est vide." << std::endl;
        return;
    }

    // Vérifier que le chemin existe
    if (path.empty()) {
        std::cerr << "Erreur : le chemin n'existe pas." << std::endl;
        return;
    }

    // Tentative pour enregistrer l'image
    bool success = cv::imwrite(path, _image);


    if (success) {
        std::cout << "L'image à été sauvegargée dans le répertoire : " << path << std::endl;
    } else {
        std::cerr << "Erreur dans l'enregistrement vers : " << path << std::endl;
    }
}

//! Afficher la taille d'une image sur un terminal
void Image::Taille()
{
    cout << "Nombre de lignes : " << _taille[0] << endl;
    cout << "Nombre de colonnes : " << _taille[1] << endl;
}

//! Calculer l'histogramme RGB d'une image
vector<vector<int>> Image::Histogramme(int bins)
{
    double minVal, maxVal;
    cv::minMaxLoc(_image, &minVal, &maxVal);

    double width = (maxVal - minVal) / bins;

    vector<int> histo_R, histo_G, histo_B, x_axis;
    vector<vector<int>> histo;

    histo_R.resize(bins);
    histo_G.resize(bins);
    histo_B.resize(bins);

    // Vecteur pour stocker les valeurs d'abscisse x
    x_axis.resize(bins);
    for (int k = 0; k < bins; k++) {
        x_axis[k] = k*width;
    }

    for (int i = 0; i < _taille[0]; i++) {
        for (int j = 0; j < _taille[1]; j++) {
            double val_R = _image.at<cv::Vec3b>(i, j)[0];
            double val_G = _image.at<cv::Vec3b>(i, j)[1];
            double val_B = _image.at<cv::Vec3b>(i, j)[2];

            for (int k = 0; k < bins; k++) {
                if (val_R > (minVal + k * width) and val_R < (minVal + (k + 1) * width))
                    histo_R[k] += 1;
                if (val_G > (minVal + k * width) and val_G < (minVal + (k + 1) * width))
                    histo_G[k] += 1;
                if (val_B > (minVal + k * width) and val_B < (minVal + (k + 1) * width))
                    histo_B[k] += 1;
            }
        }
    }
    // Mettre à jour la structure histogramme
    histo.push_back(x_axis);
    histo.push_back(histo_R);
    histo.push_back(histo_G);
    histo.push_back(histo_B);

    return histo;
}

//! Binariser une image à l'aide d'un seuil bas et d'un seuil haut
void Image::Binariser(int seuil_bas, int seuil_haut)
{
    cv::Mat bin_img = cv::Mat::zeros(_image.size(), CV_8UC1);

    for (int i = 0; i < _image.rows; i++)
    {
        for (int j = 0; j < _image.cols; j++)
        {
            if (_image.at<cv::Vec3b>(i, j)[0] >= seuil_bas && _image.at<cv::Vec3b>(i, j)[0] <= seuil_haut)
                bin_img.at<uchar>(i, j) = 255;
        }
    }

    _image = bin_img;
}

//! Transformer une image en couleur en image en niveau de gris
void Image::GreyScale()
{
    for (int i = 0; i < _taille[0]; i++) {
        for (int j = 0; j < _taille[1]; j++) {
            double val_R = _image.at<cv::Vec3b>(i, j)[0];
            double val_G = _image.at<cv::Vec3b>(i, j)[1];
            double val_B = _image.at<cv::Vec3b>(i, j)[2];

            int val = (val_R + val_G + val_B)/3;

            _image.at<cv::Vec3b>(i, j)[0] = val;
            _image.at<cv::Vec3b>(i, j)[1] = val;
            _image.at<cv::Vec3b>(i, j)[2] = val;
        }
    }

    _multicanal = false;
}

//! Isoler un canal parmis les trois
void Image::IsolerCanal(int &id)
{
    for (int i = 0; i < _taille[0]; i++) {
        for (int j = 0; j < _taille[1]; j++) {
            double val = _image.at<cv::Vec3b>(i, j)[id];

            _image.at<cv::Vec3b>(i, j)[0] = val;
            _image.at<cv::Vec3b>(i, j)[1] = val;
            _image.at<cv::Vec3b>(i, j)[2] = val;
        }
    }

    _multicanal = false;
}

//! Fonction pour la convolution entre une image de base et une image (filtre) avec condition sur les bords : =0 en dehors de l'image
void Image::Conv(cv::Mat filter) {

    // Créer une matrice pour stocker le résultat
    cv::Mat output = cv::Mat::zeros(_image.size(), _image.type());

    int filterCenterX = filter.cols / 2;
    int filterCenterY = filter.rows / 2;

    // Boucles for sur les pixels de l'image
    for (int i = 0; i < _image.rows; ++i) {
        for (int j = 0; j < _image.cols; ++j) {
            double val_R = 0.0, val_G = 0.0, val_B = 0.0;

            // Boucles for sur le filtre
            for (int k = 0; k < filter.rows; ++k) {
                for (int l = 0; l < filter.cols; ++l) {
                    int imageX = i + k - filterCenterY;
                    int imageY = j + l - filterCenterX;

                    // Mettre à jour le pixel s'il possède une position valide  (dans les bornes de l'image initiale)
                    if (imageX >= 0 && imageX < _image.rows && imageY >= 0 && imageY < _image.cols) {
                        val_R += _image.at<cv::Vec3b>(imageX, imageY)[0] * filter.at<double>(k, l);
                        val_G += _image.at<cv::Vec3b>(imageX, imageY)[1] * filter.at<double>(k, l);
                        val_B += _image.at<cv::Vec3b>(imageX, imageY)[2] * filter.at<double>(k, l);
                    }
                }
            }

            // Attribuer les nouvelles valeurs à l'image de sortie en vérifier quelle se trouvent dans le bon intervall [0, 255]
            output.at<cv::Vec3b>(i, j)[0] = cv::saturate_cast<uchar>(val_R);
            output.at<cv::Vec3b>(i, j)[1] = cv::saturate_cast<uchar>(val_G);
            output.at<cv::Vec3b>(i, j)[2] = cv::saturate_cast<uchar>(val_B);
        }
    }

    _image = output;
}

//! Fonction pour générer un filtre gaussien
cv::Mat Image::generateGaussianFilter(int size, double sigma) {
    cv::Mat gaussianFilter(size, size, CV_64F);
    double sum = 0.0;

    // Fonction gaussienne
    for (int i = -size/2; i <= size/2; i++) {
        for (int j = -size/2; j <= size/2; j++) {
            double value = std::exp(-(i*i + j*j) / (2.0 * sigma * sigma));
            gaussianFilter.at<double>(i + size/2, j + size/2) = value;
            sum += value;
        }
    }

    // Normalisation en sortie
    gaussianFilter /= sum;

    return gaussianFilter;
}

//! Fonction pour générer et appliquer un filtre gaussien sur l'image en choissiant la taille du filtre et son paramètre de variance sigma
void Image::applyGaussianBlur(int size, double sigma){
    cv::Mat filter = generateGaussianFilter(size, sigma);
    Image::Conv(filter);
}

//! Fonction pour générer et appliquer un filtre moyenneur de taille variable
void Image::applyMoyFilter(int size){
    // Créer une matrice d'éléments unité
    cv::Mat filter = cv::Mat::ones(size, size, CV_64F);
    cv::Mat ones(size, size, CV_64F);
    double sum = 0.0;

    // Calcul des valeurs pour le filtre moyenneur
    for (int i = -size/2; i <= size/2; i++) {
        for (int j = -size/2; j <= size/2; j++) {
            double value = 1;
            ones.at<double>(i + size/2, j + size/2) = value;
            sum += value;
        }
    }

    // Normalisation
    ones /= sum;

    Image::Conv(ones);
}

//! Fonction pour générer un filtre exponentiel --> Pose actuellemnt des problèmes
cv::Mat Image::generateExpFilter(int size, double lambda) {
    cv::Mat filter(size,size,CV_64F);
    float sum = 0.0;

    // Appliquer la formule du filtre exponentiel à chaque pixel
    for (int i = 0; i < filter.rows; ++i) {
        for (int j = 0; j < filter.cols; ++j) {
            filter.at<double>(i+size/2, j+ size/2) = (lambda * lambda / 4.0 )* std::exp(-lambda * (i + j));
            sum +=  (lambda * lambda / 4.0 )* std::exp(-lambda * (i + j));
        }
    }

    // Normaliser
    filter /= sum;

    return filter;
}

//! Appliquer le filtre exponentiel
void Image::applyExpFilter(int size, double lambda)
{
    cv::Mat filter = generateExpFilter(size, lambda);
    Conv(filter);
}

//! Detecter les contours avc un filtre lapalcien
void Image::DetectContours() {
    // Assure that the image is in grayscale
    if (_multicanal) {
        Image::GreyScale();
        _multicanal = false;
    }

    cv::Mat LaplacianImage;

    // Création d'un filtre laplacien
    cv::Mat laplacianFilter = (cv::Mat_<double>(3, 3) << 0, -1, 0, -1, 4, -1, 0, -1, 0);

    // Application du filtre laplacien pour la détection des contours
    Conv(laplacianFilter);
}


//! Application des gradients de type Sobel dans les direction X et Y pour la détection de contours
void Image::DetectContoursGradient() {
    // Conversion en niveaux de gris
    if (_multicanal) {
        Image::GreyScale();
        _multicanal = false;
    }

    // Copier l'image originale
    cv::Mat img_ini = _image.clone();

    // Créer les gradients Sobel dans les direction X et Y
    cv::Mat sobelFilterX = (cv::Mat_<double>(3, 3) << -1, 0, 1, -2, 0, 2, -1, 0, 1);
    cv::Mat sobelFilterY = (cv::Mat_<double>(3, 3) << -1, -2, -1, 0, 0, 0, 1, 2, 1);

    // Appliquer le gradient dans la direction X
    Conv(sobelFilterX);
    cv::Mat GradX = _image.clone();

    // Réinitialiser l'image
    _image = img_ini.clone();

    // Appliquer le gradient dans la direction Y
    Conv(sobelFilterY);
    cv::Mat GradY = _image.clone();

    // Valeur absolu des gradient
    cv::Mat absGradX, absGradY;
    cv::absdiff(GradX, cv::Scalar::all(0), absGradX);
    cv::absdiff(GradY, cv::Scalar::all(0), absGradY);

    // Normalisation
    _image = absGradX + absGradY;
    cv::normalize(_image, _image, 0, 255, cv::NORM_MINMAX, CV_8U);
}

//! Gradient selon la direction X
void Image::DetectContoursGradientX() {
    // Assure that the image is in grayscale
    if (_multicanal) {
        Image::GreyScale();
        _multicanal = false;
    }

    // Création des gradients de Sobel
    cv::Mat sobelFilterX = (cv::Mat_<double>(3, 3) << -1, 0, 1, -2, 0, 2, -1, 0, 1);

    // Appliquer le gradient X à l'image
    Conv(sobelFilterX);

    // Normaliser dans l'intervalle [0, 255]
    cv::convertScaleAbs(_image, _image);
}

//! Gradient selon la direction Y
void Image::DetectContoursGradientY() {
    // Assure that the image is in grayscale
    if (_multicanal) {
        Image::GreyScale();
        _multicanal = false;
    }

    // Création des gradients de Sobel
    cv::Mat sobelFilterY = (cv::Mat_<double>(3, 3) << -1, -2, -1, 0, 0, 0, 1, 2, 1);

    // Appliquer le gradient Y à l'image
    Conv(sobelFilterY);

    // Normaliser dans l'intervalle [0, 255]
    cv::convertScaleAbs(_image, _image);
}

//! Algorithme de rehaussement de contours en utilisant un filtre laplacien
void Image::EnhanceContoursLaplacian(double alpha, double seuil) {
    // Conversion l'image en niveaux de gris
    if (_multicanal) {
        GreyScale();
        _multicanal = false;
    }

    // Copier l'image originale
    cv::Mat img_ini = _image.clone();

    // Définition du filtre laplacien en tant que constante globale
    cv::Mat laplacianFilter = (cv::Mat_<double>(3, 3) << 0, 1, 0, 1, -4, 1, 0, 1, 0);

    // Appliquer le filtre Laplcien pour détecter les contours
    Conv(laplacianFilter);
    cv::Mat contours = _image.clone();

    _image = alpha*(contours > seuil) + img_ini;
    cv::normalize(_image, _image, 0, 255, cv::NORM_MINMAX, CV_8U);

}


//! Operator = qui rend chaques attribut du membre de droite égal à l'attribut du membre de gauche
Image& Image::operator=(const Image& other) {
    if (this != &other) {
        _image = other._image.clone();  // Deep copy of the cv::Mat member
        _taille = other._taille;
        _multicanal = other._multicanal;
        _path = other._path;
        _ID = other._ID;
    }
    return *this;
}
