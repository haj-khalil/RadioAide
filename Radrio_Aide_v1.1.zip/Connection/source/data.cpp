﻿#include "data.h"

// TODO : faire la correction pour que même si le même nomre d'images sont présentes, si les deux ID associé ne sont
// pas égaux alors on créé des éléments jusqu'à ce que ce soit le cas

//! Constructeur pour l'élément nul
Data::Data()
{

}

//! Constructeur à partir des chemins vers les fichiers de descriptreus et d'images
Data::Data(string &img_path, string &desc_path)
{
    std::vector<int> img_ids;
    std::vector<string> img_file_list = Data::file_list(img_path);
    for (size_t i = 0; i < img_file_list.size(); ++i) {
        // Ajout des images à la liste d'image
        Image img = Image(img_file_list[i], true);
        _img_list.push_back(img);
        img_ids.push_back(img.getID());
    }

    std::vector<int> desc_ids;
    std::vector<string> desc_file_list = Data::file_list(desc_path);
    for (size_t i = 0; i < desc_file_list.size(); ++i) {
        // Ajout des descripteurs à la liste
        std::vector<string> lines = Login::file_to_lines(desc_file_list[i],0);
        descripteur desc = descripteur(lines, desc_file_list[i]);
        desc.affiche();
        _desc_list.push_back(desc);
        desc_ids.push_back(desc.getID());
    }

    std::vector<int> missing_ids;

    // Vérifier quels ID d'images ne sont pas dans les ID des descripteurs
    for (const auto& element : img_ids) {
        if (std::find(desc_ids.begin(), desc_ids.end(), element) == desc_ids.end()) {
            missing_ids.push_back(element);
        }
    }

    // Vérifier quels ID de descripteurs ne sont pas dans les ID des images
    for (const auto& element : desc_ids) {
        if (std::find(img_ids.begin(), img_ids.end(), element) == img_ids.end()) {
            missing_ids.push_back(element);
        }
    }

    // Gérer les cas où il y a plus de descripteurs que d'images ou inversement
    cout << "[Data] taille des listes de descripteurs et d'images : " << _desc_list.size() << "  |  " << _img_list.size() << endl;
    int  cpt = 0;
    while (_desc_list.size() > _img_list.size())
    {
        cout << "Création d'images pour combler le manque" << endl;
        int id = missing_ids[cpt];
        string path = img_path+"/"+to_string(id)+".png";

        // Créer une image vierge
        Image img = Image();
        img.setID(id);
        img.setPath(path);

        // La sauvegarder dans le dossier de travail
        img.Save(img.getPath());

        _img_list.push_back(img);

        cpt++;
    }
    while (_desc_list.size() < _img_list.size())
    {
        int id = missing_ids[cpt];
        string path = desc_path+to_string(id)+".txt";;

        cout << _img_list[cpt].getID() << " Création descripteurs pour combler le manque - chemin : " << path << endl;

        // Créer une image vierge
        descripteur desc = descripteur();
        desc.setID(id);
        desc.setPath(path);

        desc.affiche();

        // La sauvegarder dans le dossier de travail
        desc.writeToFile(desc.getPath());

        _desc_list.push_back(desc);

        cpt++;
    }

    // Mettre les images dans le même ordre que les indices du descripteur
    std::vector<Image> sorted_img_list = _img_list;
    for (int j=0; j<desc_file_list.size(); j++)
    {
        for(int i=0; i<desc_file_list.size(); ++i)
        {
            if (_img_list[i].getID() == _desc_list[j].getID()) sorted_img_list[j] = _img_list[i];
        }
    }

    _img_list = sorted_img_list;

    // Générer automatiquement les tailles et poids des images
    for (int j=0; j<desc_file_list.size(); j++)
    {
        string taille = _img_list[j].getSizeStr();
        _desc_list[j].setTaille(taille);

        cv::Mat img = _img_list[j].getImage();
        size_t imageSizeBytes = img.total() * img.elemSize();


        _desc_list[j].setPoids(imageSizeBytes);
        _desc_list[j].writeToFile(_desc_list[j].getPath());
    }
}

// Methods
//! Convertir les éléments d'un fichier en lignes
std::vector<std::string> Data::file_list(string &dir_path)
{
    std::vector<std::string> file_list;
    DIR *dir = opendir(dir_path.c_str());

    if (dir == NULL)
    {
        cout << "Impossible d'ouvrir le dossier";
    }

    struct dirent *object; // object soit un fichier ou directory
        while ((object = readdir(dir)) != NULL)
        {
            if (object->d_type == DT_REG)
            {
                std::string fullPath = dir_path + "/" + object->d_name;
                cout << fullPath << endl;
                file_list.push_back(fullPath);
            }
        }

        closedir(dir);

        return file_list;
}

//! Trier en fonction de l'ID du descripteur du descripteur
void Data::triID(bool inv)
{
    std::vector<descripteur> cp_desc_list = _desc_list;
    std::vector<descripteur> sorted_desc_list = _desc_list;

    std::vector<Image> sorted_img_list = _img_list;

    int min_l;
    int size = cp_desc_list.size();

    std::vector<int> sorting(size,0);

    int rank_minl=0,Nloc;

    for (int i=0;i<size;i++){
        Nloc = size-i;
        min_l = cp_desc_list[0].getID();
        rank_minl = 0;

        // Recherche du minimum
        for (int j=0;j<Nloc;j++){
            if (cp_desc_list[j].getID()<min_l){min_l = cp_desc_list[j].getID(); rank_minl=j;}
        }

        // Actualiser TAB
        sorted_desc_list[i] = cp_desc_list[rank_minl];
        sorting[i] = rank_minl;

        // Supprimer une value spécifique d'un vecteur
        cp_desc_list.erase(cp_desc_list.begin() + rank_minl);
    }

    // Si inv est vrai alors le tri se fera dans le sens opposé
    if (inv)
    {
        std::reverse(sorted_desc_list.begin(), sorted_desc_list.end());
    }

    _desc_list = sorted_desc_list;

    // Mettre les images dans le même ordre que les ID des descripteurs
    for (int i=0;i<size;i++){
        _img_list[i] = sorted_img_list[sorting[i]];
        sorted_img_list.erase(sorted_img_list.begin() + sorting[i]);
    }

    if (inv) std::reverse(_img_list.begin(),_img_list.end());
}

//! Trier les données en fonction de la variable coût du descripteur
void Data::triCout(bool inv)
{
    std::vector<descripteur> cp_desc_list = _desc_list;
    std::vector<descripteur> sorted_desc_list = _desc_list;

    std::vector<Image> sorted_img_list = _img_list;

    int min_l;
    int size = cp_desc_list.size();

    std::vector<int> sorting(size,0);

    int rank_minl=0,Nloc;

    for (int i=0;i<size;i++){
        Nloc = size-i;
        min_l = cp_desc_list[0].getCout();
        rank_minl = 0;

        // Recherche du minimum
        for (int j=0;j<Nloc;j++){
            if (cp_desc_list[j].getCout()<min_l){min_l = cp_desc_list[j].getCout(); rank_minl=j;}
        }

        // Actualiser TAB
        sorted_desc_list[i] = cp_desc_list[rank_minl];
        sorting[i] = rank_minl;

        // Supprimer une value spécifique d'un vecteur
        cp_desc_list.erase(cp_desc_list.begin() + rank_minl);
    }

    // Si inv est vrai alors le tri se fait dans le sens inverse
    if (inv)
    {
        std::reverse(sorted_desc_list.begin(), sorted_desc_list.end());
    }

    _desc_list = sorted_desc_list;

    // Mettre les images dans le même ordre que les ID des descripteurs
    for (int i=0;i<size;i++){
        _img_list[i] = sorted_img_list[sorting[i]];
        sorted_img_list.erase(sorted_img_list.begin() + sorting[i]);
    }

    if (inv) std::reverse(_img_list.begin(),_img_list.end());
}

//! Ajouter un élément aux données en renseignant l'image et le descripteur
void Data::addElem(Image &img, descripteur &desc)
{
    _desc_list.push_back(desc);
    _img_list.push_back(img);
}

//! Supprimer un élément des données en renseignant sont rank dans la liste de données
void Data::deleteElem(int pos)
{
    _desc_list.erase(_desc_list.begin() + pos);
    _img_list.erase(_img_list.begin() + pos);
}

//! Retourner le nombre de descripteur de l'image
int Data::getDescSize()
{
    return _desc_list.size();
}

// Getters
string Data::get(int &elem_idx, int &desc_idx)
{
    string element;

    descripteur desc = _desc_list[desc_idx];
    element = desc.getLines()[elem_idx];

    return element;
}

Image Data::getImg(int &img_idx)
{
    return _img_list[img_idx];
}

descripteur& Data::getDesc(int &desc_idx)
{
    return _desc_list[desc_idx];
}


//! Exporter la bibliothèque de donnée vers un dossier
void Data::exportData(string &path)
{
    int size = _img_list.size();
    string ext = ".png";

    // Création des dossiers pour stocker les images
    boost::filesystem::create_directory(path+"/image/");
    boost::filesystem::create_directory(path+"/descripteur/");

    for (int i=0;i<size;i++){
        _img_list[i].Save(path+"/image/"+to_string(_img_list[i].getID())+ext);
        _desc_list[i].writeToFile(path+"/descripteur/"+to_string(_desc_list[i].getID())+".txt");
    }
}

//! Nettoyer les fichiers de la bibliothèque daans le répertoire de travail
void Data::cleanDir(string &path)
{
    try {
        boost::filesystem::remove_all(path);
        std::cout << "Le dossier à été supprimé." << std::endl;
    } catch (const boost::filesystem::filesystem_error& e) {
        std::cerr << "Erreur lors de la suppression : " << e.what() << std::endl;
    }
}

//! Nettoyer les fichiers d'un dossier et recréé l'arborescence attendue dans l'application
void Data::cleanData()
{
    // Nettoyer les fichiers initiaux
    string path_img = "../Connection/image/";
    string path_desc = "../Connection/descripteur/";
    cleanDir(path_img);
    cleanDir(path_desc);

    // Créer les dossier pour le stockage des images
    boost::filesystem::create_directory("../Connection/image/");
    boost::filesystem::create_directory("../Connection/image/temp");
    boost::filesystem::create_directory("../Connection/descripteur/");
}

//! Affichage avec condition sur le coût des éléments des  données
void Data::tri_conditionnel(float inf, float sup)
{
    int cpt=0;
    int size = _desc_list.size();

    for (int i=0; i<size; i++)
    {
        cout << size << " | " << _desc_list[i-cpt].getCout() << "  " << inf << "  " << sup;
        if (_desc_list[i-cpt].getCout()<inf || _desc_list[i-cpt].getCout()>sup)
        {
            cout << "  *";
            _desc_list.erase(_desc_list.begin()+i-cpt);
            _img_list.erase(_img_list.begin()+i-cpt);
            cpt++;
        }
        cout << endl;
    }
}
