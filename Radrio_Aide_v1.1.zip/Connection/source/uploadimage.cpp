#include "uploadimage.h"
#include "ui_uploadimage.h"


// TODO : ajouter possibilité de charger une image sans avoir de bibliothèque initialement

//! Constructor
UploadImage::UploadImage(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UploadImage)
{
    ui->setupUi(this);
}

//! Desctuctorr
UploadImage::~UploadImage()
{
    delete ui;
}

//! Test pour savoir si tous les champs nécessaire à la création d'un nouvel élément de la base de donnée snt remplis
int UploadImage::input_test(std::vector<std::string> info)
{
    int vide = 0;
    for (int i = 0; i < info.size(); i++)
    {
        cout<<"Information : "<<info[i]<<endl;
        if(info[i]==""){
            vide++;
        }
    }
    cout<<vide <<"Test terminé"<<endl;
    return vide;
}

//! Fonction pour écrire un nouveau fichier descripteur dans le répertoiire /Connection/descripteur/ avec les informations renseignées
void UploadImage::creat_descripteur_file(std::vector<std::string> descripteur_info)
{
     fstream myFile;
     std::vector<string> file_liste = Login::file_list();

     // Algorithme pour trouver le nom du nouvel élément ajouté en fonction de l'ID descripteur le plus élevé trouvé dans la bibliothèque actuelle
     int latest_id = stoi(Login::file_to_lines(file_liste[file_liste.size() -1],0)[0]);
     for (int i = 0; i < file_liste.size() ; i++)
     {
         if(Login::file_to_lines(file_liste[i],0)[0]!=""){
         int id = stoi(Login::file_to_lines(file_liste[i],0)[0]);

         if (latest_id < id)
         {
             latest_id = id;
         }}
     }


    myFile.open("../Connection/descripteur/" + to_string(latest_id+1) + ".txt", ios::out);
    if (myFile.is_open())
    {
        for (int i = 0; i < descripteur_info.size(); i++)
        {
            if (i != 0)
            {
                myFile << descripteur_info[i] << endl;
            }
            else
            {
                myFile << to_string(latest_id+1) << endl;
            }
        }
    }
        myFile.close();
        cout << "file of descripteur is created  " << to_string(latest_id) << endl;
         UploadImage::changerNomEtCopierImage(QString::number(latest_id+1));

};

//! Récupérer les informations renseignées dans les champs de l'interface
std::vector<string> UploadImage::getNewINfo()
{
    std::vector<string> info;

     string  id="12";
     QString type =ui->Acces_choice->currentText();
     QString patient =ui->input_patient->text();
     QString cout =ui->input_cout->text();

     QString  source =ui->input_source->text();
     QString  technique =ui->input_technique->text();
     QString  titre =ui->input_title->text();
     QString  poids = ui->input_poids->text();
     QString  taille = ui->input_taille->text();

     info.push_back(id);
     info.push_back(titre.toStdString());
     info.push_back(patient.toStdString());
     info.push_back(technique.toStdString());

     info.push_back(type.toStdString());
     info.push_back(cout.toStdString());
     info.push_back(poids.toStdString());
     info.push_back(source.toStdString());
     info.push_back(taille.toStdString());


return info;
}

//TODO : corriger l'erreur lorsque la base de donnée initiale est vide : segmentation fault
//! Sauvegarder le nouvel élément de la bibliothèque - Erreur quand la bibliothèque est vide
void UploadImage::on_ptn_save_clicked()
{
    try {
        std::vector<string>  info=UploadImage::getNewINfo();
        int test =UploadImage::input_test(info);



        if(test == 0 ){

            try {
                 descripteur desc = descripteur(info,"");

                 UploadImage::creat_descripteur_file(info);

                 QMessageBox::information(this, "Information", QString("Ajout réussi, appuyer sur le bouton 'recharger' pour afficher les changements"));
                 hide() ;

            }  catch (const std::exception& e) {
                QMessageBox::warning(this, "Attention", QString("Certaines cases ne contiennent pas le bon type d'informations"));
            }


        }else QMessageBox::warning(this,"Attention","Certaines cases ne sont pas vides");
    }  catch (const std::exception& e) {
        QString errorMessage = QString::fromUtf8(e.what());
        QMessageBox::warning(this, "Attention", "Une erreur est survenue: " + errorMessage);
    }

}



//!  Fonction pour renseigner dans une interface Qt le chemin vers l'image à charger
void UploadImage::on_ptn_parcourir_clicked()
{


    QString imagePath = QFileDialog::getOpenFileName(this, tr("Select Image"), QCoreApplication::applicationDirPath(), tr("Images (*.png *.jpg *.bmp)"));

        if (!imagePath.isEmpty()) {
            // Affichage de l'image sélectionnée
            QPixmap image(imagePath);
            ui->label_image->setPixmap(image);
            ui->label_image->setScaledContents(true);

            ui->input_path->setText(imagePath);

            Image newimg = Image(imagePath.toStdString(), true);

            ui->input_taille->setText(QString::fromStdString(newimg.getSizeStr()));

            cv::Mat img = newimg.getImage();
            size_t imageSizeBytes = img.total() * img.elemSize();

            ui->input_poids->setText(QString::number(static_cast<qulonglong>(imageSizeBytes)));
        }

}

//! Gnérer une image de base à l'aide de l'élément nulle de la classe Image
void UploadImage::on_generate_img_clicked()
{
    Image img = Image();

    string imagePath = "../Connection/image/temp/temp.png";

    img.Save(imagePath);
    // Display the selected image
    QPixmap image(QString::fromStdString(imagePath));
    ui->label_image->setPixmap(image);
    ui->label_image->setScaledContents(true);

    ui->input_path->setText(QString::fromStdString(imagePath));
}


//! Changer le nom et copier une image vers la base de données
void UploadImage::changerNomEtCopierImage( QString nouveauNom ) {
    QString ancienChemin = ui->input_path->text();
    // Changer le nom de l'image
    QString nouveauChemin = "../Connection/image/";

    // Charger l'image
    cv::Mat image = cv::imread(ancienChemin.toStdString());

    std::string cheminSortie = nouveauChemin.toStdString();

    std::string nomFichierSortie = nouveauNom.toStdString()+".png";

    std::string cheminImageSortie = cheminSortie + nomFichierSortie;

    if (cv::imwrite(cheminImageSortie, image)) {
        std::cout << "image est bien enregistré" << std::endl;

    }
}

//! Quitter la fenêtre d'ajout d'un élément à la base de données
void UploadImage::on_quit_btn_clicked()
{
    hide();
}
