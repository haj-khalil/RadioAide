#include "user.h"

//! Constructor de l'élement nul
User::User()
{
    _role = 0;
    _username = "John";
}

//! Constructor d'un objet de type utilisateur en fonction de son rôle et son nom
User::User(int role, string username)
{
    _role = role;
    _username = username;

    cout << "L'utilisateur : " << username << " possède le niveau d'accès : " << role << endl;
}

// Setters
void User::setRole(int role){
    _role = role;
}

void User::setUsername(string username){
    _username = username;
}

//  Getters
int User::getRole(){
    return _role;
}

string User::getUsername(){
    return _username;
}
